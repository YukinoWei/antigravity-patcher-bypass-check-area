---
name: ag2-desktop
description: 操作与诊断 Antigravity 2.0 桌面版：读取安装/版本/授权闸门状态、查看用户设置与 MCP 注册、列举技能与项目、抓取 language_server 与主进程日志、写设置/注册 MCP、启动应用。当用户提到 Antigravity 2.0 桌面版、language_server、~/.gemini/config/config.json、MCP 注册、面板或 2.0 启动失败时使用。
---

# Antigravity 2.0 桌面版运维技能

本技能由 `antigravity2-plugin` 提供，配套 21 个 MCP 工具（`ag2_*`）。目标是让助手在不手写 PowerShell/文件读写的前提下，安全地观察和调整 2.0 桌面版的状态。

## 关键事实（来自 2.28.2 实战）

| 事实 | 值 |
| --- | --- |
| 应用目录 | `%LOCALAPPDATA%\Programs\antigravity`（含 `Antigravity.exe`、`resources/app.asar`、`resources/bin/language_server.exe`） |
| 用户设置 | `~/.gemini/config/config.json` → `userSettings` |
| MCP 配置 | `~/.gemini/settings.json` → `mcpServers`（`{command,args}` 走 stdio，`{httpUrl}` 走 HTTP） |
| 技能目录 | `~/.gemini/skills/<name>/SKILL.md` |
| 数据目录 | `~/.gemini/antigravity` |
| 日志 | `%APPDATA%\Antigravity\logs\language_server.log`、`logs\main.log` |
| 调试端口 | `%APPDATA%\Antigravity\DevToolsActivePort`（首行端口，次行 browser WS 路径） |
| 启动方式 | 主进程 spawn `language_server.exe --standalone --override_ide_name antigravity --subclient_type hub --https_server_port 0 …`，窗口加载 `https://127.0.0.1:<port>/` |

## 使用顺序

1. **先看状态**：`ag2_status`（应用、版本、解锁状态、进程端口）→ 需要细节再 `ag2_doctor`。
2. **看配置**：`ag2_settings_get`、`ag2_mcp_list`、`ag2_skills_list`、`ag2_projects_list`。
3. **排障**：`ag2_logs_tail({source:"language_server", lines:200})`，再 `ag2_logs_tail({source:"main"})`；启动失败常见原因是端口占用、CSRF 不一致、language_server 缺失。
4. **改配置**：`ag2_settings_set({key,value})`、`ag2_mcp_add({name, command, args})` 或 `{name, httpUrl}`；每个写操作都会先备份 `<file>.bak` 并返回 before/after，改完提醒用户重启应用。
5. **启动/深链**：`ag2_launch({args:["--headless"]})` 或 `{deepLink:"antigravity://..."}`。
6. **自动修复**：`ag2_heal_status` 看开关/间隔/当前闸门/上次结果/定时任务；`ag2_heal_now` 立刻修一次；
   `ag2_heal_config({enabled:false})` 关闭。插件安装后会自己定时检查，Google 更新把它改回去会自动改回，
   一般不需要主动调用 —— 只有排障或用户要求「现在就修」时才用 `ag2_heal_now`。

## 注意

- `ag2_binary_state` 的 `patched` 表示 language_server 的 `hasValidAuth` 闸门已被改写（解锁态），`unpatched` 表示仍是原版；
  该工具只读。真正的写入只由自动修复（`lib/heal.js` / `ag2_heal_now`）执行：先备份 `<ls>.agybak`，写完复验，失败回滚。
- 写 `settings.json` 时保留其它键；不要删除用户已有的 MCP 服务器（除非用户明确要求 `ag2_mcp_remove`）。
- 面板：`ag2_panel({action:"open"})` 返回带令牌的回环地址 `http://127.0.0.1:47913/?token=…`，令牌存于 `~/.gemini/ag2-plugin/panel-token`。
