# Antigravity 2.0 Desktop Plugin

[![ci](https://github.com/avencores-port/antigravity2-plugin/actions/workflows/ci.yml/badge.svg?branch=main)](https://github.com/avencores-port/antigravity2-plugin/actions/workflows/ci.yml)
[![license: GPL-3.0-or-later](https://img.shields.io/badge/license-GPL--3.0--or--later-blue.svg)](LICENSE)
[![node](https://img.shields.io/badge/node-%E2%89%A518-3c873a.svg)](package.json)
[![MCP](https://img.shields.io/badge/MCP-2025--06--18-6f42c1.svg)](https://modelcontextprotocol.io)
[![platform](https://img.shields.io/badge/platform-Windows%20%7C%20macOS%20%7C%20Linux-lightgrey.svg)](#2-快速开始)

把 **Antigravity 2.0 桌面版**（Electron 壳 + `language_server.exe`）自身的运维能力抽出来，做成一个可安装的插件：
一个 **MCP 服务器**（18 个工具）+ 一个 **技能**（`ag2-desktop`）+ 一个 **本地控制面板**。

> 与 `antigravity-unlock`（IDE / VS Code 插件，改 `main.js`、`extension.js`）不同：本项目**只针对 2.0 桌面版**，
> 它在架构上是一个 Electron 应用，业务逻辑全在 `resources/bin/language_server.exe`（Go）里，UI 是
> `https://127.0.0.1:<动态端口>/` 的网页。所以「插件」在 2.0 里的正确落点是 **MCP 服务器 + 技能**，
> 而不是 VS Code 扩展。

## 文档索引

| 文档 | 内容 |
| --- | --- |
| [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) | 模块职责、请求生命周期、面板协议、安装布局、失败模式 |
| [docs/REVERSE-ENGINEERING.md](docs/REVERSE-ENGINEERING.md) | asar 格式、启动链路、数据面路径、IPC 清单、签名表、未知项 |
| [docs/PUBLISH.md](docs/PUBLISH.md) | 发布到 GitHub / 发版 / 仓库设置 / 自查清单 |
| [CONTRIBUTING.md](CONTRIBUTING.md) | 开发环境、目录约定、硬性约束、加工具的最小步骤 |
| [SECURITY.md](SECURITY.md) | 漏洞报告方式与安全边界 |
| [CHANGELOG.md](CHANGELOG.md) | 版本记录 |

---

## 1. 它做了什么

| 能力 | 说明 |
| --- | --- |
| 状态总览 | 安装目录、版本（读 `app.asar` 内 `package.json`）、`language_server` 路径/大小、授权闸门状态、调试端口 |
| 授权闸门判定 | 扫描 `language_server` 的 `hasValidAuth` 签名（x64 / arm64），判定 `patched / unpatched / unsupported` |
| **自动应用** | 安装即修一次；MCP 服务器每次被拉起时再修一次；系统定时任务每 5 分钟检查 —— Google 更新把它改回去后**自动改回**，用户无需任何操作 |
| 路径清单 | `~/.gemini` 下配置、技能、项目、数据目录与 `%APPDATA%\Antigravity` 日志/端口/存储 |
| 日志 | `language_server.log`、`main.log` 尾部（512 KB 窗口，最多 2000 行） |
| 用户设置 | 读/写 `~/.gemini/config/config.json` 的 `userSettings`（写前备份 `<file>.bak`） |
| MCP 注册 | 列/增/删 `~/.gemini/settings.json` 的 `mcpServers`（stdio `command+args` 或 `httpUrl`），保留其它键 |
| 技能 | 列技能、读某个 `SKILL.md` |
| 项目 | 列 `~/.gemini/config/projects/*.json`，按修改时间倒序 |
| UI 存储 | 读/写 `%APPDATA%\Antigravity\app_storage.json` 的键 |
| 调试端口 | 解析 `DevToolsActivePort`，给出 CDP 端点，方便附加调试 |
| 启动 | 启动/重连桌面版，支持 `--wsl-distro=`、附加参数、`antigravity://` 深链 |
| 自检 | 12 项环境检查（安装、版本、二进制、权限、配置可写、日志、端口、运行时、自动修复等） |
| 控制面板 | 回环 HTTP 面板：应用/设置/MCP/技能/项目/日志一屏，带令牌鉴权 |
| CLI | `ag2 status/install/uninstall/doctor/tools/call/serve/panel/logs/paths/heal/autostart` |

写操作统一策略：**先备份、再原子写（tmp+rename）、返回 before/after**；失败不半写。

---

## 2. 快速开始

```bash
# 1) 看当前状态（不需要安装）
node bin/ag2.js status

# 2) 预览安装计划
node bin/ag2.js install --dry-run

# 3) 安装：复制到 ~/.gemini/ag2-plugin/app，生成 MCP 垫片，写 settings.json，安装技能
node bin/ag2.js install

# 4) 重启 Antigravity 2.0，MCP 列表里会出现 antigravity2-plugin
# 5) 打开控制面板
node bin/ag2.js panel
```

安装后目录：

```
~/.gemini/ag2-plugin/
├── app/                 # 插件代码副本（server.js、lib/、panel/、skill/）
├── run-mcp.cmd          # Windows 垫片：ELECTRON_RUN_AS_NODE=1 "<运行时>" "<app>/server.js"
├── run-mcp.sh           # POSIX 垫片
├── panel-token          # 面板令牌（0600）
└── install.log
~/.gemini/settings.json  # mcpServers["antigravity2-plugin"] = { command: <垫片>, args: [] }
~/.gemini/skills/ag2-desktop/SKILL.md
```

- **没有系统 node 也能跑**：安装器优先用 `node`，找不到就退回 App 自带的 Electron
  （`ELECTRON_RUN_AS_NODE=1 ...\Antigravity.exe`），实测 `node 24.21.0 / electron 44.5.1`。
- 想用指定运行时：`AG2_NODE=D:\path\to\node.exe node install.js`。
- 卸载：`node bin/ag2.js uninstall`（只删自己注册的项与目录，保留其它 MCP 服务器）。

---

## 自动应用（headless，安装即生效）

装好插件之后**什么都不用点**：

1. `ag2 install` 结束前立刻检查一次闸门，未解锁就当场写入（先备份、写完复验、失败回滚）。
2. `server.js` 每次被宿主拉起（每次打开 Antigravity 2.0 会话）时，在后台再检查一次；不阻塞 MCP 握手、不写 stdout。
3. 安装器注册一个系统级定时触发，每 5 分钟跑一次：
   - Windows：`schtasks` 任务 `Antigravity2PluginHeal`（建任务需要管理员权限；拿不到就自动退回登录启动
     `Start Menu/Programs/Startup/ag2-heal.vbs`，由 wscript 静默拉起常驻守护，同样无需用户操作）
   - macOS：`~/Library/LaunchAgents/com.avencores.antigravity2.heal.plist`（`RunAtLoad` + `StartInterval`）
   - Linux：`systemd --user` 的 `.service` + `.timer`，没有 systemd 时退回 `crontab`

Google 推送新版本时会把 `language_server` 整体覆盖回原版闸门 —— 下一轮检查发现 `unpatched`，就按同样的
「备份 → 定点写入 → 复验 → 失败回滚」流程改回解锁态。整个过程没有 UI、没有弹窗、没有需要用户确认的步骤。

```bash
ag2 heal                 # 立刻检查并修复一次
ag2 heal --status        # 开关 / 间隔 / 当前闸门 / 上次结果 / 定时任务
ag2 heal --off           # 关闭自动修复（仍保留手动 ag2 heal）
ag2 heal --restore       # 用 <ls>.agybak 还原
ag2 autostart --status   # 定时任务的注册详情
ag2 autostart --remove   # 移除定时任务
```

配置在 `~/.gemini/ag2-plugin/heal-config.json`（默认 `{"enabled":true,"intervalSeconds":300}`），
状态在 `heal-state.json`，日志在 `heal.log`。

> 说明：这一步会写 `language_server` 的少量字节，因此它和「只读探测」是两套路径 —— `ag2_binary_state`
> 永远只读；写入只发生在 `lib/heal.js`，并且一定有备份、有复验、有回滚。

---

## 3. MCP 工具（21 个）

只读：`ag2_status`、`ag2_paths`、`ag2_logs_tail`、`ag2_settings_get`、`ag2_mcp_list`、`ag2_skills_list`、
`ag2_skill_read`、`ag2_projects_list`、`ag2_storage_get`、`ag2_devtools_port`、`ag2_binary_state`、`ag2_doctor`

写入：`ag2_settings_set`、`ag2_mcp_add`、`ag2_mcp_remove`、`ag2_storage_set`

动作：`ag2_launch`、`ag2_panel`

自动修复：`ag2_heal_status`、`ag2_heal_now`、`ag2_heal_config`

协议：MCP stdio，**一行一个 JSON-RPC 2.0**；支持 `2024-11-05 / 2025-03-26 / 2025-06-18`，默认 `2025-06-18`；
支持通知、批量数组、`ping`、`resources/*`、`prompts/*` 空列表。

调试单个工具：

```bash
node bin/ag2.js call ag2_status
node bin/ag2.js call ag2_logs_tail '{"source":"language_server","lines":200}'
node bin/ag2.js call ag2_mcp_add '{"name":"demo","command":"node","args":["server.js"]}'
```

---

## 4. 控制面板

```bash
node bin/ag2.js panel            # 默认 http://127.0.0.1:47913/?token=…
node bin/ag2.js panel --port 0   # 随机端口
```

- 只监听 `127.0.0.1`；令牌存 `~/.gemini/ag2-plugin/panel-token`，首页需 `?token=`，随后下发
  `HttpOnly; SameSite=Strict` Cookie；API 一律校验。
- 路由：`GET /`、`GET /api/state`、`GET /api/ping`、`POST /api/action`
  （`settings.set`、`mcp.add`、`mcp.remove`、`launch`、`logs.tail`、`storage.set`、`doctor`）。
- 面板 8 秒自动刷新，也可被 MCP 工具 `ag2_panel` 打开。

---

## 5. 为什么落在这些路径（逆向得到的事实）

2.28.2 的 `resources/app.asar`（`dist/main.js` 523 KB、`ipcHandlers.js`、`paths.js`…）表明：

| 事实 | 值 |
| --- | --- |
| 应用标识 | `package.json`: `name=antigravity`, `productName=Antigravity`, `main=dist/main.js` |
| 用户设置 | `~/.gemini/config/config.json` → `userSettings` |
| MCP 配置 | `~/.gemini/settings.json` → `mcpServers` |
| 技能 | `~/.gemini/skills/<name>/SKILL.md` |
| 数据目录 | `getAppDataDirName() = app.getName().toLowerCase().replace(/\s+/g,'')` → `~/.gemini/antigravity` |
| 日志 | `app.getPath('logs')/language_server.log`，即 `%APPDATA%\Antigravity\logs\` |
| 调试端口 | `userData/DevToolsActivePort`（首行端口、次行 browser WS 路径） |
| 启动 | spawn `language_server.exe --standalone --override_ide_name antigravity --subclient_type hub --https_server_port 0 --csrf_token <64hex> --app_data_dir antigravity --enable_sidecars …`，窗口 `loadURL("https://127.0.0.1:<port>/")` |
| 插件面 | ① MCP 服务器 ② 技能 ③ sidecar 扩展（`--enable_sidecars` + `extensions:send-authorities` + `plugin://` scheme） |

第三种「sidecar 扩展」需要往 `language_server` 进程注入 authority 映射并由协议层反代，属于二进制级集成；
本插件选择 ①②（官方配置面、可逆、无需改二进制），把 sidecar 留给后续版本。

### 授权闸门签名（只读判定用）

`language_server` 里 `hasValidAuth` 的 x64 形态：

```
未解锁  80 78 08 00 74 ?  48 8b ? 24 ? 48 89 ? 60
已解锁  c6 40 08 01 90 90 48 8b ? 24 ? 48 89 ? 60
```

arm64 形态为 `03 20 40 39 ... 36 ...` → `23 00 80 52 03 20 00 39 ...`（详见 `lib/runtime.js` 的 `LS_GATES`）。
`ag2_binary_state` / `ag2_status` **只读**这两个签名判断当前状态；真正写入只发生在自动修复模块（`lib/heal.js`），
写入前先复制 `<language_server>.agybak`，写完立刻重新扫描复验，任一步失败就用备份回滚。

---

## 6. 目录结构

```
antigravity2-plugin/
├── plugin.json             # 插件清单（id/entry/transport/skill/target）
├── package.json            # npm 元数据 + 脚本（test / pack / verify）
├── server.js               # MCP stdio 入口（拉起时后台触发一次自动修复）
├── heal.js                 # 自动修复入口（--once/--daemon/--status/--restore/--on/--off）
├── install.js              # 安装器（复制 + 垫片 + settings.json + 技能 + 卸载）
├── lib/
│   ├── mcp.js              # 极简 MCP 服务端（JSON-RPC over stdio）
│   ├── runtime.js          # 路径/发现/asar 版本/签名扫描/日志/端口
│   ├── heal.js             # 自动修复核心：备份 → 定点写 → 复验 → 回滚
│   ├── autostart.js        # 定时触发：schtasks / LaunchAgent / systemd --user / crontab
│   ├── tools.js            # 21 个工具定义与处理器
│   └── panel.js            # 回环面板 HTTP 服务（令牌 + CSP）
├── panel/index.html        # 控制面板（零外部依赖，无外链）
├── skill/ag2-desktop/SKILL.md
├── bin/ag2.js              # CLI（status/install/doctor/tools/call/serve/panel/logs/heal/autostart）
├── test/                   # 夹具测试：mcp / install / panel / heal / all / verify-registered
├── docs/                   # 架构、逆向记录、发布指南
├── .github/                # CI（win+linux × node 20/22）、Issue/PR 模板
├── build-zip.py            # 打 dist/*.zip（纯 Python，无第三方库）
├── SECURITY.md · CONTRIBUTING.md · CHANGELOG.md · LICENSE
└── .gitignore · .gitattributes · .editorconfig
```

---

## 7. 测试

```bash
node test/mcp.test.js      # 26 项：握手、tools/list、各工具结果、错误码、批量
node test/install.test.js  # 30 项：dry-run、复制、垫片、注册、备份、幂等、卸载
node test/panel.test.js    # 25 项：令牌鉴权、状态聚合、动作落盘、404/400、生命周期
node test/heal.test.js     # 44 项：修复/幂等/被更新还原后修回/关闭开关/未知签名不写/arm64/还原/陈旧锁
node test/all.js           # 四套一起跑
node test/verify-registered.js  # 真机验收：按 settings.json 的注册项拉起服务器并握手
```

测试全部在临时目录里造「假安装 + 假 HOME」（`AG2_HOME` / `AG2_APP_DIR`），不触碰真实安装。

---

## 8. 安全与可逆性

- 面板只回环监听 + 随机令牌 + HttpOnly Cookie，页面无任何外链资源（CSP `default-src 'none'`，仅放行内联样式/脚本与同源 `fetch`）。
- 所有写入先 `<file>.bak`，再 `tmp + rename` 原子替换；`settings.json` 只动 `mcpServers` 下自己的键。
- 卸载只删除自己创建的文件与注册项。
- `app.asar` 永远只读。`language_server` 只在自动修复时写入 6 字节（x64）或 8 字节（arm64）的闸门修复，
  写前复制 `.agybak`、写后复验、失败回滚；`ag2_binary_state` 等探测路径始终只读。
- 自动修复默认开启（`enabled:true`），可随时 `ag2 heal --off` 关闭；关闭后不再有任何写入。

## 9. 许可

GPL-3.0-or-later。逆向与实现参考了公开项目 `AvenCores/open-antigravity-patcher`（GPL-3.0）的签名语义与
`antigravity-unlock` 的工程结构；`Antigravity` 商标归 Google 所有，本项目与其无隶属关系。

欢迎 Issue / PR：先读 [CONTRIBUTING.md](CONTRIBUTING.md)；安全问题走 [SECURITY.md](SECURITY.md)（不要开公开 Issue）。
