#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""打包插件为 dist/antigravity2-plugin-<version>.zip（纯标准库，保留 UTF-8 文件名）。"""
import io
import json
import os
import sys
import zipfile

ROOT = os.path.dirname(os.path.abspath(__file__))
DIST = os.path.join(ROOT, 'dist')
INCLUDE = ['plugin.json', 'server.js', 'heal.js', 'install.js', 'package.json',
           'README.md', 'LICENSE', 'CHANGELOG.md', 'SECURITY.md', 'CONTRIBUTING.md',
           'lib', 'panel', 'skill', 'bin', 'docs']
EXCLUDE_DIRS = {'test', 'dist', 'node_modules', '.git', '.github', '__pycache__'}
EXCLUDE_FILE_SUFFIX = ('.bak', '.agybak', '.pyc', '.zip', '.log')


def walk(rel):
    full = os.path.join(ROOT, rel)
    if os.path.isfile(full):
        yield rel
        return
    for name in sorted(os.listdir(full)):
        if name in EXCLUDE_DIRS:
            continue
        child = os.path.join(rel, name)
        if os.path.isdir(os.path.join(ROOT, child)):
            for item in walk(child):
                yield item
        elif not name.endswith(EXCLUDE_FILE_SUFFIX):
            yield child


def main():
    version = json.load(io.open(os.path.join(ROOT, 'plugin.json'), encoding='utf-8'))['version']
    os.makedirs(DIST, exist_ok=True)
    out = os.path.join(DIST, 'antigravity2-plugin-%s.zip' % version)
    if os.path.exists(out):
        os.remove(out)

    entries = []
    for item in INCLUDE:
        if os.path.exists(os.path.join(ROOT, item)):
            entries.extend(walk(item))

    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for rel in entries:
            zf.write(os.path.join(ROOT, rel), rel.replace(os.sep, '/'))

    size = os.path.getsize(out)
    print('打包完成: %s' % out)
    print('条目: %d  大小: %d 字节 (%.1f KB)' % (len(entries), size, size / 1024.0))
    for rel in entries:
        print('  + %s' % rel)

    with zipfile.ZipFile(out) as zf:
        bad = zf.testzip()
        print('完整性: %s' % ('OK' if bad is None else '损坏: %s' % bad))
        assert bad is None
    return 0


if __name__ == '__main__':
    sys.exit(main())
