'use strict';
/**
 * 安装器：把本插件落地到用户目录，并注册到 Antigravity 2.0 的 MCP 配置里。
 *
 *   node install.js            安装（已安装则覆盖代码，保留配置）
 *   node install.js --dry-run  只打印计划
 *   node install.js --status   查看安装状态
 *   node install.js --uninstall 卸载（移除 MCP 注册、技能与插件目录）
 *
 * 落地位置（全部使用 paths()，可通过 AG2_HOME 做夹具测试）：
 *   ~/.gemini/ag2-plugin/app/          插件代码
 *   ~/.gemini/ag2-plugin/run-mcp.cmd   启动垫片（Windows）／ run-mcp.sh
 *   ~/.gemini/settings.json            mcpServers["antigravity2-plugin"]
 *   ~/.gemini/skills/ag2-desktop/      技能
 */
const fs = require('fs');
const path = require('path');
const R = require('./lib/runtime');

const SOURCE_ROOT = __dirname;
const NAME = 'antigravity2-plugin';
const SKILL_NAME = 'ag2-desktop';
const COPY_INCLUDE = ['server.js', 'heal.js', 'plugin.json', 'README.md', 'LICENSE', 'CHANGELOG.md', 'lib', 'panel', 'bin', 'skill'];
const COPY_EXCLUDE = /(^|[\\/])(node_modules|test|dist|\.git|.*\.bak|.*\.agybak|.*\.vsix)([\\/]|$)/;

function backupFile(file) {
  if (!fs.existsSync(file)) return null;
  const bak = file + '.bak';
  if (fs.existsSync(bak)) return bak;
  fs.copyFileSync(file, bak);
  return bak;
}

function pluginPaths() {
  const p = R.paths();
  const root = p.pluginHome;
  return {
    root,
    app: path.join(root, 'app'),
    shimWin: path.join(root, 'run-mcp.cmd'),
    shimPosix: path.join(root, 'run-mcp.sh'),
    log: path.join(root, 'install.log'),
    skill: path.join(p.skills, SKILL_NAME),
    settings: p.settings,
  };
}

function copyTree(src, dst, skip, log) {
  const st = fs.statSync(src);
  if (st.isDirectory()) {
    fs.mkdirSync(dst, { recursive: true });
    for (const entry of fs.readdirSync(src)) {
      const s = path.join(src, entry);
      if (skip.test(s)) continue;
      copyTree(s, path.join(dst, entry), skip, log);
    }
    return;
  }
  fs.copyFileSync(src, dst);
  if (log) log.push('复制 ' + path.relative(SOURCE_ROOT, src));
}

/** 选运行时：优先真 node，其次 App 自带 Electron（ELECTRON_RUN_AS_NODE）。 */
function pickRuntime(app) {
  const cands = R.resolveRuntime(app) || [];
  const plain = cands.find((c) => c.kind === 'env' || c.kind === 'node');
  if (plain) return { kind: 'node', cmd: plain.cmd, needsElectronNode: false };
  const el = cands.find((c) => c.kind === 'electron');
  if (el) return { kind: 'electron', cmd: el.cmd, needsElectronNode: true };
  throw new Error('找不到可用运行时（既无 node，也未定位到 Antigravity.exe）');
}

function writeShim(pp, rt, log) {
  const isWin = R.isWin;
  const nodeExe = rt.cmd;
  const needsElectronNode = rt.needsElectronNode;
  const shim = isWin ? pp.shimWin : pp.shimPosix;
  const body = isWin
    ? ['@echo off', 'setlocal', needsElectronNode ? 'set "ELECTRON_RUN_AS_NODE=1"' : '', '"' + nodeExe + '" "' + path.join(pp.app, 'server.js') + '" %*', 'exit /b %ERRORLEVEL%', ''].filter(Boolean).join('\r\n')
    : ['#!/bin/sh', needsElectronNode ? 'export ELECTRON_RUN_AS_NODE=1' : '', 'exec "' + nodeExe + '" "' + path.join(pp.app, 'server.js') + '" "$@"', ''].filter(Boolean).join('\n');
  fs.writeFileSync(shim, body, { mode: 0o755 });
  if (!isWin) {
    try {
      fs.chmodSync(shim, 0o755);
    } catch {}
  }
  if (log) log.push((isWin ? '写入垫片 run-mcp.cmd（' : '写入垫片 run-mcp.sh（') + rt.kind + '）');
  return shim;
}

function registerMcp(pp, shim, log) {
  const settings = fs.existsSync(pp.settings) ? R.readJson(pp.settings, {}) || {} : {};
  const before = JSON.stringify(settings.mcpServers || {});
  const bak = backupFile(pp.settings);
  settings.mcpServers = settings.mcpServers || {};
  settings.mcpServers[NAME] = { command: shim, args: [] };
  R.writeJson(pp.settings, settings);
  if (log) {
    log.push('备份 settings.json → ' + (bak ? path.basename(bak) : '（新建文件，无需备份）'));
    log.push('注册 mcpServers.' + NAME + ' → ' + shim + (before === JSON.stringify(settings.mcpServers) ? '（无变化）' : ''));
  }
  return settings;
}

function unregisterMcp(pp, log) {
  if (!fs.existsSync(pp.settings)) return false;
  const settings = R.readJson(pp.settings, {}) || {};
  if (!settings.mcpServers || !settings.mcpServers[NAME]) return false;
  backupFile(pp.settings);
  delete settings.mcpServers[NAME];
  R.writeJson(pp.settings, settings);
  if (log) log.push('已从 settings.json 移除 mcpServers.' + NAME);
  return true;
}

function installSkill(pp, log) {
  const src = path.join(SOURCE_ROOT, 'skill', SKILL_NAME);
  if (!fs.existsSync(src)) return false;
  copyTree(src, pp.skill, COPY_EXCLUDE, null);
  if (log) log.push('安装技能 → ' + pp.skill);
  return true;
}

function install(opts) {
  const options = opts || {};
  const pp = pluginPaths();
  const log = [];
  const app = R.findApp();
  if (!app) throw new Error('未找到 Antigravity 2.0 安装目录（可用 AG2_APP_DIR 指定）');
  const rt = pickRuntime(app);
  if (options.dryRun) {
    return {
      dryRun: true,
      app: app.dir,
      version: app.version,
      runtime: { kind: rt.kind, cmd: rt.cmd },
      steps: [
        '复制插件代码 → ' + pp.app,
        '写入 MCP 垫片 → ' + (R.isWin ? pp.shimWin : pp.shimPosix),
        '注册 mcpServers.' + NAME + ' → ' + pp.settings,
        '安装技能 → ' + pp.skill,
        '注册自动修复定时任务（' + (options.autostart === false ? '跳过（--no-autostart）' : '每 ' + (options.intervalSeconds || 300) + ' 秒') + '）',
        '立即执行一次自动修复（把 language_server 的闸门改回已解锁）',
      ],
    };
  }

  fs.mkdirSync(pp.root, { recursive: true });
  fs.rmSync(pp.app, { recursive: true, force: true });
  fs.mkdirSync(pp.app, { recursive: true });
  for (const item of COPY_INCLUDE) {
    const src = path.join(SOURCE_ROOT, item);
    if (fs.existsSync(src)) copyTree(src, path.join(pp.app, item), COPY_EXCLUDE, log);
  }
  const shim = writeShim(pp, rt, log);
  registerMcp(pp, shim, log);
  installSkill(pp, log);

  // 自动应用：先注册定时触发（开机/常驻），再立刻修一次。
  let autostart = null;
  if (options.autostart !== false) {
    try {
      autostart = require('./lib/autostart').register({ intervalSeconds: options.intervalSeconds || 300 });
      log.push('自动修复定时任务 → ' + (autostart.ok ? autostart.kind + '（' + (autostart.name || autostart.unit || autostart.line || '已注册') + '）' : '失败：' + autostart.detail));
    } catch (err) {
      autostart = { ok: false, detail: (err && err.message) || String(err) };
      log.push('自动修复定时任务 → 失败：' + autostart.detail);
    }
  } else {
    log.push('自动修复定时任务 → 跳过（--no-autostart）');
  }

  let heal = null;
  try {
    const H = require('./lib/heal');
    heal = H.healOnce({ reason: 'install' });
    log.push(
      '自动修复 → ' +
        heal.result +
        (heal.changed
          ? '（' + heal.arch + ' @0x' + Number(heal.offset).toString(16) + '，已备份 ' + path.basename(heal.backup || '') + '）'
          : heal.message
            ? '（' + heal.message + '）'
            : '')
    );
  } catch (err) {
    heal = { ok: false, result: 'error', message: (err && err.message) || String(err) };
    log.push('自动修复 → 失败：' + heal.message);
  }

  fs.writeFileSync(pp.log, '[' + new Date().toISOString() + '] install ' + NAME + '\n' + log.join('\n') + '\n', 'utf8');
  return { ok: true, app: app.dir, version: app.version, app2: pp.app, shim, settings: pp.settings, skill: pp.skill, autostart, heal, steps: log };
}

function uninstall(opts) {
  const pp = pluginPaths();
  const log = [];
  if (opts && opts.dryRun) {
    return { dryRun: true, steps: ['移除 mcpServers.' + NAME, '删除 ' + pp.app, '删除技能 ' + pp.skill] };
  }
  try {
    const r = require('./lib/autostart').unregister();
    log.push('自动修复定时任务 → ' + (r.detail || '已移除'));
  } catch (err) {
    log.push('自动修复定时任务 → 移除失败：' + ((err && err.message) || String(err)));
  }
  unregisterMcp(pp, log);
  if (fs.existsSync(pp.skill)) {
    fs.rmSync(pp.skill, { recursive: true, force: true });
    log.push('已删除技能目录 ' + pp.skill);
  }
  for (const f of [pp.shimWin, pp.shimPosix, path.join(pp.root, 'heal.cmd'), path.join(pp.root, 'heal.sh')]) {
    if (fs.existsSync(f)) {
      fs.rmSync(f, { force: true });
      log.push('已删除垫片 ' + f);
    }
  }
  if (fs.existsSync(pp.app)) {
    fs.rmSync(pp.app, { recursive: true, force: true });
    log.push('已删除插件目录 ' + pp.app);
  }
  return { ok: true, steps: log };
}

function status() {
  const pp = pluginPaths();
  const settings = fs.existsSync(pp.settings) ? R.readJson(pp.settings, {}) || {} : {};
  const entry = (settings.mcpServers || {})[NAME] || null;
  return {
    installed: !!(entry && fs.existsSync(pp.app)),
    pluginHome: pp.root,
    app: pp.app,
    appExists: fs.existsSync(path.join(pp.app, 'server.js')),
    shim: R.isWin ? pp.shimWin : pp.shimPosix,
    shimExists: fs.existsSync(R.isWin ? pp.shimWin : pp.shimPosix),
    settings: pp.settings,
    registered: !!entry,
    entry,
    skill: pp.skill,
    skillExists: fs.existsSync(path.join(pp.skill, 'SKILL.md')),
  };
}

module.exports = { install, uninstall, status, pluginPaths, NAME, SKILL_NAME };

if (require.main === module) {
  const argv = process.argv.slice(2);
  const dryRun = argv.includes('--dry-run');
  try {
    if (argv.includes('--status')) {
      console.log(JSON.stringify(status(), null, 2));
    } else if (argv.includes('--uninstall')) {
      const res = uninstall({ dryRun });
      console.log(dryRun ? '计划：' : '已卸载：');
      for (const line of res.steps) console.log('  - ' + line);
    } else {
      const res = install({
        dryRun,
        autostart: !argv.includes('--no-autostart'),
        intervalSeconds: Number((argv.find((a) => a.startsWith('--interval=')) || '').split('=')[1]) || 300,
      });
      console.log(dryRun ? '安装计划：' : '安装完成：');
      for (const line of res.steps) console.log('  - ' + line);
      if (!dryRun) console.log('\n重启 Antigravity 2.0 后即可在 MCP 服务器列表看到 ' + NAME);
    }
  } catch (err) {
    console.error('失败：' + err.message);
    process.exitCode = 1;
  }
}
