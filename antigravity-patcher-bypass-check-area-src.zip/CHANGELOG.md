# Changelog

## 1.1.0 — 2026-11-16

自动应用 / 自动修复：装好插件后不再需要手动「应用」，Google 更新把它改回去会自动改回。

### 新增
- `lib/heal.js`：`healOnce()`（备份 → 定点写入 → 复验 → 失败回滚）、`healRestore()`、`healDaemon()`、
  `spawnHealOnce()`、`status()`；快速路径缓存（文件 size/mtime + 应用版本未变则不重复扫描 174 MB）
- `lib/autostart.js`：每 5 分钟的系统级触发（Windows `schtasks` / macOS LaunchAgent / Linux `systemd --user`，
  无 systemd 退回 `crontab`），带 `register` / `unregister` / `status`
- `heal.js` 入口 + CLI：`ag2 heal [--status|--on|--off|--restore|--daemon] [--json]`、`ag2 autostart [--status|--remove] [--interval=]`
- MCP 工具 3 个：`ag2_heal_status`、`ag2_heal_now`、`ag2_heal_config`（共 21 个）
- 安装器：安装结束立即修一次 + 注册定时任务；`--no-autostart` / `--interval=<秒>`；卸载时移除任务
- `server.js`：每次被宿主拉起时后台触发一次修复（`AG2_NO_AUTOFIX=1` 可关闭）
- `test/heal.test.js`（44 项）

### 变更
- `plugin.json`：版本 1.1.0，`capabilities.tools=21`，新增 `autoHeal` / `scheduledHeal`
- `SECURITY.md` / `CONTRIBUTING.md` / `README.md`：补充写入边界（仅 `lib/heal.js`、可回滚、可关闭）


## [未发布] 开源整理

- 仓库化：`.gitignore` / `.gitattributes` / `.editorconfig`，CI（Windows + Ubuntu × Node 20/22）
- 协作面：`CONTRIBUTING.md`、`SECURITY.md`、Issue 表单（bug / feature）、PR 模板
- 文档：`docs/ARCHITECTURE.md`、`docs/REVERSE-ENGINEERING.md`、`docs/PUBLISH.md`，README 增加徽章与文档索引
- `package.json` 补齐 `repository` / `homepage` / `bugs` / `keywords` / `os`，`plugin.json` 同步仓库字段
- 打包脚本纳入 `docs/` 与 `SECURITY.md` / `CONTRIBUTING.md`（19 条目）
- 无功能变更、无 API 变更

## 1.0.0 — 2026-11-16

首个版本：把 Antigravity 2.0 桌面版自身的运维能力抽成 MCP 插件。

### 新增

- **MCP stdio 服务器**（`server.js` + `lib/mcp.js`）：自动协商协议版本
  （`2024-11-05` / `2025-03-26` / `2025-06-18`），一行一个 JSON-RPC 2.0，支持通知、批量数组与标准错误码。
- **18 个工具**：状态、路径、日志、用户设置读写、MCP 注册增删查、技能列表/读取、项目列表、UI 存储读写、
  调试端口、`language_server` 授权闸门只读判定、自检、启动/深链、面板。
- **安装器**（`install.js`）：复制到 `~/.gemini/ag2-plugin/app`，生成 `run-mcp.cmd|sh` 垫片
  （无系统 node 时自动退回 App 自带 Electron 的 `ELECTRON_RUN_AS_NODE` 模式），
  注册 `settings.json` 的 `mcpServers["antigravity2-plugin"]`，安装 `ag2-desktop` 技能；支持
  `--dry-run` / `--status` / `--uninstall`。
- **控制面板**（`lib/panel.js` + `panel/index.html`）：回环监听 + 令牌 + HttpOnly Cookie，
  深色中文界面，应用/设置/MCP/技能/项目/日志一屏，8 秒自动刷新。
- **CLI**（`bin/ag2.js`）：`status / install / uninstall / doctor / tools / call / serve / panel / logs / paths`。
- **测试**：协议 26 项、安装 30 项、面板 25 项，全部在夹具 `AG2_HOME` / `AG2_APP_DIR` 上运行。

### 事实来源（2.28.2 逆向）

- `app.asar` 的 `dist/paths.js`：`~/.gemini/antigravity`、`~/.gemini/config/config.json`、
  `userData/app_storage.json`、`userData/DevToolsActivePort`、`logs/language_server.log`。
- `dist/main.js` + `dist/constants.js`：spawn `language_server.exe --standalone --subclient_type hub …`，
  窗口载入 `https://127.0.0.1:<动态端口>/`。
- `dist/customScheme.js`：sidecar 扩展通过 `plugin://<authority>` 反代（本版未使用，留作后续）。
- 授权闸门签名沿用 `open-antigravity-patcher` 的 x64 / arm64 形态，仅用于**只读判定**。