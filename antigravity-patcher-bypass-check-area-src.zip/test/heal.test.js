'use strict';
/**
 * 自动修复（heal）测试：在夹具安装目录上验证「安装即修 / 被更新还原后自动修回」。
 *
 * 覆盖：
 *   1. 未解锁 → 定点写入 → 复验通过，备份 <ls>.agybak 生成，文件大小不变
 *   2. 再跑一次 → already（快速路径 cached）
 *   3. 模拟 Google 更新把闸门改回去 → 再次修回，且不覆盖旧备份
 *   4. 关闭开关 → disabled，不动文件
 *   5. 签名不认识（版本变了）→ unsupported，绝不写入
 *   6. language_server 不存在 → missing
 *   7. arm64 夹具 → patched，写入 arm64 修复字节
 *   8. healRestore 用备份还原 → 再自动修回
 *   9. status()/files()/state 形状
 *  10. 清锁：残留 pid 的锁会被判为 stale 并接管
 */
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const F = require('./fixture');

let pass = 0;
const fails = [];
function check(name, fn) {
  try {
    fn();
    pass++;
    console.log('  ✓ ' + name);
  } catch (err) {
    fails.push(name + ' → ' + err.message);
    console.log('  ✗ ' + name + ' → ' + err.message);
  }
}

const X64_FIX = Buffer.from('c64008019090', 'hex');
const ARM64_FIX = Buffer.from('2300805203200039', 'hex');
const ARM64_SIG = Buffer.from('03204039' + '03000036' + '00000000' + '031006a9', 'hex');
const ARM64_PATCHED = Buffer.from('2300805203200039' + '00000000' + '031006a9', 'hex');

function arm64Binary() {
  const junk = Buffer.alloc(32, 0x90);
  return Buffer.concat([Buffer.from('MZ fake arm64', 'latin1'), junk, ARM64_SIG, junk]);
}

function at(buf, offset, len) {
  return buf.slice(offset, offset + len);
}

async function main() {
  const home = F.makeHome({});
  const appDir = F.makeApp({ version: '2.28.2' });
  const lsFile = path.join(appDir, 'resources', 'bin', 'language_server.exe');
  const bakFile = lsFile + '.agybak';
  const env = { AG2_HOME: home, AG2_APP_DIR: appDir, APPDATA: path.join(home, 'AppData', 'Roaming'), AG2_NODE: process.execPath };

  await F.withEnv(env, async () => {
    const H = require('../lib/heal');
    const R = require('../lib/runtime');

    const original = fs.readFileSync(lsFile);
    const offset = original.indexOf(F.UNPATCHED_X64);
    check('夹具里能找到未解锁签名', () => assert.ok(offset > 0));

    console.log('1) 首次自动修复');
    const first = H.healOnce({ reason: 'test-install' });
    check('结果为 patched', () => assert.strictEqual(first.result, 'patched'));
    check('标记 changed', () => assert.strictEqual(first.changed, true));
    check('架构 x64', () => assert.strictEqual(first.arch, 'x64'));
    check('偏移与签名位置一致', () => assert.strictEqual(first.offset, offset));
    check('文件大小不变', () => assert.strictEqual(fs.statSync(lsFile).size, original.length));
    check('修复字节已写入', () => assert.deepStrictEqual(at(fs.readFileSync(lsFile), offset, 6), X64_FIX));
    check('签名之后的字节未被破坏', () =>
      assert.deepStrictEqual(at(fs.readFileSync(lsFile), offset + 6, 9), F.UNPATCHED_X64.slice(6))
    );
    check('备份 .agybak 已创建', () => assert.ok(fs.existsSync(bakFile)));
    check('备份内容 = 原始文件', () => assert.deepStrictEqual(fs.readFileSync(bakFile), original));
    check('返回 backupCreated=true', () => assert.strictEqual(first.backupCreated, true));
    check('复验为 patched', () => assert.strictEqual(R.analyzeBinary(lsFile).state, 'patched'));

    console.log('2) 幂等');
    const second = H.healOnce({ reason: 'test-again' });
    check('第二次 already', () => assert.strictEqual(second.result, 'already'));
    check('第二次未必走缓存（cached 仅表示快速路径）', () => assert.ok(second.changed === false));
    check('文件仍是 patched', () => assert.deepStrictEqual(at(fs.readFileSync(lsFile), offset, 6), X64_FIX));

    console.log('3) Google 更新把闸门改回去');
    // 模拟安装器覆盖 language_server：写回未解锁签名 + 更新时间戳
    fs.writeFileSync(lsFile, original);
    const future = new Date(Date.now() + 5000);
    fs.utimesSync(lsFile, future, future);
    const afterUpdate = H.healOnce({ reason: 'test-after-update' });
    check('自动改回 patched', () => assert.strictEqual(afterUpdate.result, 'patched'));
    check('复验通过', () => assert.strictEqual(R.analyzeBinary(lsFile).state, 'patched'));
    check('复用旧备份（不覆盖）', () => assert.strictEqual(afterUpdate.backupCreated, false));
    check('旧备份内容仍是原始字节', () => assert.deepStrictEqual(fs.readFileSync(bakFile), original));

    console.log('4) 关闭开关');
    H.writeConfig({ enabled: false });
    fs.writeFileSync(lsFile, original);
    const off = H.healOnce({ reason: 'test-disabled' });
    check('result=disabled', () => assert.strictEqual(off.result, 'disabled'));
    check('关闭时不动文件', () => assert.deepStrictEqual(fs.readFileSync(lsFile), original));
    H.writeConfig({ enabled: true });

    console.log('5) 签名不认识（版本变了）');
    const weird = Buffer.concat([Buffer.from('MZ weird build', 'latin1'), Buffer.alloc(128, 0x11)]);
    fs.writeFileSync(lsFile, weird);
    const unknown = H.healOnce({ reason: 'test-unsupported', force: true });
    check('result=unsupported', () => assert.strictEqual(unknown.result, 'unsupported'));
    check('unsupported 不写入', () => assert.deepStrictEqual(fs.readFileSync(lsFile), weird));
    check('unsupported 不报 ok', () => assert.strictEqual(unknown.ok, false));

    console.log('6) language_server 缺失');
    fs.unlinkSync(lsFile);
    const missing = H.healOnce({ reason: 'test-missing', force: true });
    check('result=missing', () => assert.strictEqual(missing.result, 'missing'));
    const restoreNoBackup = (() => {
      fs.writeFileSync(lsFile, original);
      const snap = fs.readFileSync(lsFile);
      const r = H.healRestore();
      return { r, snap };
    })();
    check('还原成功（备份存在）', () => assert.strictEqual(restoreNoBackup.r.result, 'restored'));
    check('还原后与备份一致', () => assert.deepStrictEqual(fs.readFileSync(lsFile), original));

    console.log('7) 还原后再自动修回');
    const again = H.healOnce({ reason: 'test-repatch', force: true });
    check('再次 patched', () => assert.strictEqual(again.result, 'patched'));
    check('文件已解锁', () => assert.strictEqual(R.analyzeBinary(lsFile).state, 'patched'));

    console.log('8) arm64 夹具');
    const armDir = F.makeApp({ version: '2.28.2', lsBinary: arm64Binary() });
    const armLs = path.join(armDir, 'resources', 'bin', 'language_server.exe');
    const armBytes = fs.readFileSync(armLs);
    // 用 AG2_APP_DIR 切到 arm64 夹具
    const prev = process.env.AG2_APP_DIR;
    process.env.AG2_APP_DIR = armDir;
    const arm = H.healOnce({ reason: 'test-arm64', force: true });
    process.env.AG2_APP_DIR = prev;
    check('arm64 结果为 patched', () => assert.strictEqual(arm.result, 'patched'));
    check('架构识别为 arm64', () => assert.strictEqual(arm.arch, 'arm64'));
    check('写入 arm64 修复字节', () =>
      assert.deepStrictEqual(at(fs.readFileSync(armLs), arm.offset, 8), ARM64_FIX)
    );
    check('arm64 文件大小不变', () => assert.strictEqual(fs.statSync(armLs).size, armBytes.length));
    check('arm64 patched 复验', () => {
      const saved = process.env.AG2_APP_DIR;
      process.env.AG2_APP_DIR = armDir;
      const st = R.analyzeBinary(armLs).state;
      process.env.AG2_APP_DIR = saved;
      assert.strictEqual(st, 'patched');
    });

    console.log('9) 状态与文件');
    const st = H.status({ live: true });
    check('status 有 config', () => assert.strictEqual(typeof st.config.enabled, 'boolean'));
    check('status 间隔默认 300 秒', () => assert.strictEqual(st.config.intervalSeconds, 300));
    check('status 读到应用版本', () => assert.strictEqual(st.app.version, '2.28.2'));
    check('status.live.state=patched', () => assert.strictEqual(st.live.state, 'patched'));
    const files = H.files();
    check('配置文件路径在插件目录', () => assert.ok(files.config.indexOf(path.join('.gemini', 'ag2-plugin')) > 0));
    check('日志文件已写入', () => assert.ok(fs.existsSync(files.log)));
    const state = H.readState();
    check('state 记录 attempts', () => assert.ok(state.attempts >= 1));
    check('state 记录上次 result', () => assert.strictEqual(state.result, 'patched'));

    console.log('10) 陈旧锁接管');
    fs.writeFileSync(path.join(path.dirname(files.config), 'heal.lock'), JSON.stringify({ pid: 999999, at: Date.now() - 60 * 60 * 1000 }));
    fs.writeFileSync(lsFile, original);
    const locked = H.healOnce({ reason: 'test-stale-lock', force: true });
    check('陈旧锁不阻塞（仍能修）', () => assert.strictEqual(locked.result, 'patched'));
    check('锁已释放', () => assert.ok(!fs.existsSync(path.join(path.dirname(files.config), 'heal.lock'))));
  });

  F.rmrf(home);
  F.rmrf(appDir);

  console.log('');
  if (fails.length) {
    console.log('失败 ' + fails.length + ' 项：');
    for (const f of fails) console.log('  - ' + f);
    process.exitCode = 1;
  } else {
    console.log('heal：' + pass + ' 项全部通过');
  }
}

main().catch((err) => {
  console.error('测试崩溃：', err && err.stack ? err.stack : err);
  process.exitCode = 1;
});
