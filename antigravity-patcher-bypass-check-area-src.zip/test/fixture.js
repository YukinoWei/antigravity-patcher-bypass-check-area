'use strict';
/**
 * 测试夹具：在临时目录里造一个「假的 Antigravity 2.0 安装」+ 假的 HOME，
 * 这样 patch/写配置/面板等逻辑可以在不碰真实安装的情况下验证。
 */
const fs = require('fs');
const os = require('os');
const path = require('path');

// 见 lib/runtime.js：Electron 的 asar 钩子会劫持 *.asar 的读写。
if (process.versions && process.versions.electron) {
  try {
    process.noAsar = true;
  } catch {}
}

/** language_server 的 x64 hasValidAuth 闸门签名（未解锁态，用于夹具）。 */
const UNPATCHED_X64 = Buffer.from([
  0x80, 0x78, 0x08, 0x00, 0x74, 0x05, 0x48, 0x8b,
  0x4c, 0x24, 0x08, 0x48, 0x89, 0x4c, 0x60,
]);
const PATCHED_X64 = Buffer.from([
  0xc6, 0x40, 0x08, 0x01, 0x90, 0x90, 0x48, 0x8b,
  0x4c, 0x24, 0x08, 0x48, 0x89, 0x4c, 0x60,
]);

function fakeLsBinary(patched) {
  const junk = Buffer.alloc(64, 0x90);
  return Buffer.concat([Buffer.from('MZ fake language_server', 'latin1'), junk, patched ? PATCHED_X64 : UNPATCHED_X64, junk]);
}

function tmpDir(prefix) {
  return fs.mkdtempSync(path.join(os.tmpdir(), prefix || 'ag2-test-'));
}

/** 生成合法 asar（只有 package.json），用于验证 readAsarPackageJson。 */
function makeAsar(files) {
  const entries = {};
  const blobs = [];
  let offset = 0;
  for (const [name, content] of Object.entries(files)) {
    const buf = Buffer.isBuffer(content) ? content : Buffer.from(content, 'utf8');
    entries[name] = { size: buf.length, offset: String(offset) };
    blobs.push(buf);
    offset += buf.length;
  }
  const header = { files: entries };
  let jsonBuf = Buffer.from(JSON.stringify(header), 'utf8');
  const pad = (4 - (jsonBuf.length % 4)) % 4;
  const padded = Buffer.concat([jsonBuf, Buffer.alloc(pad)]);
  const headerSize = 8 + padded.length;
  const prefix = Buffer.alloc(16);
  prefix.writeUInt32LE(4, 0);
  prefix.writeUInt32LE(headerSize, 4);
  prefix.writeUInt32LE(jsonBuf.length, 8);
  prefix.writeUInt32LE(jsonBuf.length, 12);
  return Buffer.concat([prefix, padded, ...blobs]);
}

/**
 * 造安装目录：
 *   <dir>/Antigravity.exe
 *   <dir>/resources/app.asar            （package.json: name antigravity / version）
 *   <dir>/resources/bin/language_server.exe （可选二进制内容）
 */
function makeApp(opts) {
  const o = opts || {};
  const dir = o.dir || tmpDir('ag2-app-');
  fs.mkdirSync(path.join(dir, 'resources', 'bin'), { recursive: true });
  fs.writeFileSync(path.join(dir, 'Antigravity.exe'), o.exe || 'MZ fake electron shell', 'utf8');
  const pkg = { name: 'antigravity', productName: 'Antigravity', version: o.version || '2.28.2', main: 'dist/main.js' };
  fs.writeFileSync(path.join(dir, 'resources', 'app.asar'), makeAsar({ 'package.json': JSON.stringify(pkg) }));
  const ls = o.lsBinary || fakeLsBinary(!!o.patched);
  fs.writeFileSync(path.join(dir, 'resources', 'bin', 'language_server.exe'), ls);
  return dir;
}

/** 造 HOME（AG2_HOME 夹具），预置 settings.json / config.json / skills / 日志。 */
function makeHome(opts) {
  const o = opts || {};
  const home = o.home || tmpDir('ag2-home-');
  fs.mkdirSync(path.join(home, '.gemini', 'config'), { recursive: true });
  fs.mkdirSync(path.join(home, '.gemini', 'skills'), { recursive: true });
  if (o.settings !== false) {
    fs.writeFileSync(
      path.join(home, '.gemini', 'settings.json'),
      JSON.stringify({ mcpServers: { existing: { command: 'node', args: ['x.js'] } }, theme: 'dark' }, null, 2),
      'utf8'
    );
  }
  fs.writeFileSync(
    path.join(home, '.gemini', 'config', 'config.json'),
    JSON.stringify({ userSettings: { themeMode: 'THEME_MODE_DARK', permissionPreset: 'AGENT_PERMISSION_PRESET_TURBO' } }, null, 2),
    'utf8'
  );
  const skillDir = path.join(home, '.gemini', 'skills', 'demo-skill');
  fs.mkdirSync(skillDir, { recursive: true });
  fs.writeFileSync(path.join(skillDir, 'SKILL.md'), '---\nname: demo-skill\ndescription: demo\n---\n\n# Demo Skill\n', 'utf8');
  const projDir = path.join(home, '.gemini', 'config', 'projects');
  fs.mkdirSync(projDir, { recursive: true });
  fs.writeFileSync(path.join(projDir, 'p1.json'), JSON.stringify({ title: 'Demo Project', workspace: 'D:/demo' }), 'utf8');
  // 日志与端口文件放在 userData（Windows 下是 %APPDATA%\Antigravity）
  const userData = path.join(home, 'AppData', 'Roaming', 'Antigravity');
  fs.mkdirSync(path.join(userData, 'logs'), { recursive: true });
  fs.writeFileSync(path.join(userData, 'logs', 'language_server.log'), 'ls line 1\nls line 2\n', 'utf8');
  fs.writeFileSync(path.join(userData, 'logs', 'main.log'), 'main line 1\n', 'utf8');
  fs.writeFileSync(path.join(userData, 'DevToolsActivePort'), '9333\n/devtools/browser/abc-123\n', 'utf8');
  fs.writeFileSync(path.join(userData, 'app_storage.json'), JSON.stringify({ 'ide-install-wizard-shown': true }), 'utf8');
  return home;
}

/** 用一个夹具环境执行 fn：设置 AG2_HOME / AG2_APP_DIR，并清理 require 缓存。 */
async function withEnv(env, fn) {
  const saved = {};
  for (const k of Object.keys(env)) {
    saved[k] = process.env[k];
    if (env[k] == null) delete process.env[k];
    else process.env[k] = env[k];
  }
  try {
    return await fn();
  } finally {
    for (const k of Object.keys(saved)) {
      if (saved[k] == null) delete process.env[k];
      else process.env[k] = saved[k];
    }
  }
}

function rmrf(dir) {
  try {
    fs.rmSync(dir, { recursive: true, force: true });
  } catch {}
}

module.exports = { tmpDir, makeAsar, makeApp, makeHome, withEnv, rmrf, fakeLsBinary, UNPATCHED_X64, PATCHED_X64 };
