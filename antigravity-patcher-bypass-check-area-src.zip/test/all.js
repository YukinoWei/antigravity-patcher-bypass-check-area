'use strict';
/**
 * 跑全部测试：node test/all.js
 * 各套测试都是独立进程（MCP 那套需要真实子进程 + 干净的环境变量）。
 */
const path = require('path');
const { spawnSync } = require('child_process');

const SUITES = [
  ['MCP 协议', 'mcp.test.js'],
  ['安装器', 'install.test.js'],
  ['控制面板', 'panel.test.js'],
  ['自动修复', 'heal.test.js'],
];

let failed = 0;
const summary = [];

for (const [label, file] of SUITES) {
  console.log('\n=== ' + label + ' (' + file + ') ===');
  const res = spawnSync(process.execPath, [path.join(__dirname, file)], {
    stdio: 'inherit',
    env: Object.assign({}, process.env, { ELECTRON_RUN_AS_NODE: '1' }),
    windowsHide: true,
  });
  const ok = res.status === 0;
  if (!ok) failed++;
  summary.push((ok ? '✓ ' : '✗ ') + label);
}

console.log('\n=== 汇总 ===');
for (const line of summary) console.log('  ' + line);
console.log(failed ? '\n有 ' + failed + ' 套失败' : '\n全部通过');
process.exitCode = failed ? 1 : 0;
