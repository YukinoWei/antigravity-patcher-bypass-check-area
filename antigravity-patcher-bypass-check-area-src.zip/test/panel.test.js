'use strict';
/**
 * 控制面板测试：真的起 HTTP 服务，验证令牌鉴权、状态聚合与动作写入。
 */
const assert = require('assert');
const fs = require('fs');
const http = require('http');
const path = require('path');
const F = require('./fixture');

let pass = 0;
const fails = [];
function check(name, fn) {
  try {
    fn();
    pass++;
    console.log('  ✓ ' + name);
  } catch (err) {
    fails.push(name + ' → ' + err.message);
    console.log('  ✗ ' + name + ' → ' + err.message);
  }
}

function get(port, pathname, headers) {
  return new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port, path: pathname, method: 'GET', headers: headers || {} }, (res) => {
      let body = '';
      res.setEncoding('utf8');
      res.on('data', (c) => (body += c));
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body }));
    });
    req.on('error', reject);
    req.end();
  });
}

function post(port, pathname, payload, headers) {
  const data = JSON.stringify(payload || {});
  return new Promise((resolve, reject) => {
    const req = http.request(
      { host: '127.0.0.1', port, path: pathname, method: 'POST', headers: Object.assign({ 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) }, headers || {}) },
      (res) => {
        let body = '';
        res.setEncoding('utf8');
        res.on('data', (c) => (body += c));
        res.on('end', () => resolve({ status: res.statusCode, body }));
      }
    );
    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

async function main() {
  const home = F.makeHome({});
  const appDir = F.makeApp({ version: '2.28.2', patched: true });
  const env = { AG2_HOME: home, AG2_APP_DIR: appDir, APPDATA: path.join(home, 'AppData', 'Roaming') };

  await F.withEnv(env, async () => {
    delete require.cache[require.resolve('../lib/panel')];
    delete require.cache[require.resolve('../lib/runtime')];
    delete require.cache[require.resolve('../lib/tools')];
    const P = require('../lib/panel');
    const info = await P.start({ port: 0 });
    const port = info.port;

    console.log('鉴权');
    const noTok = await get(port, '/api/state');
    check('无令牌 → 401', () => assert.strictEqual(noTok.status, 401));
    const badTok = await get(port, '/api/state?token=deadbeef');
    check('错令牌 → 401', () => assert.strictEqual(badTok.status, 401));
    const rootNoTok = await get(port, '/');
    check('首页无令牌 → 401', () => assert.strictEqual(rootNoTok.status, 401));

    const root = await get(port, '/?token=' + info.token);
    check('首页带令牌 → 200', () => assert.strictEqual(root.status, 200));
    check('首页是 HTML 面板', () => assert.ok(root.body.includes('插件面板')));
    check('首页下发 HttpOnly Cookie', () => assert.ok(/ag2panel=.*HttpOnly/i.test(root.headers['set-cookie'].join(';'))));
    check('首页无外部脚本引用', () => assert.ok(!/src="https?:/i.test(root.body)));

    const cookie = { Cookie: 'ag2panel=' + info.token };

    console.log('状态聚合');
    const st = JSON.parse((await get(port, '/api/state', cookie)).body);
    check('读到应用版本', () => assert.strictEqual(st.app.version, '2.28.2'));
    check('读到解锁状态', () => assert.strictEqual(st.app.unlockState, 'patched'));
    check('读到用户设置', () => assert.strictEqual(st.settings.userSettings.themeMode, 'THEME_MODE_DARK'));
    check('读到 MCP 服务器', () => assert.ok(st.mcp.servers.some((x) => x.name === 'existing')));
    check('读到技能', () => assert.ok(st.skills.some((x) => x.name === 'demo-skill')));
    check('读到日志', () => assert.ok(st.logs.languageServer.lines.includes('ls line 2')));

    const ping = JSON.parse((await get(port, '/api/ping', cookie)).body);
    check('ping 正常', () => assert.strictEqual(ping.ok, true));

    console.log('动作');
    const setRes = JSON.parse((await post(port, '/api/action', { type: 'settings.set', key: 'themeMode', value: 'THEME_MODE_LIGHT' }, cookie)).body);
    check('settings.set 成功', () => assert.strictEqual(setRes.ok, true));
    const cfgText = fs.readFileSync(path.join(home, '.gemini', 'config', 'config.json'), 'utf8');
    check('settings.set 真实落盘', () => assert.ok(cfgText.includes('THEME_MODE_LIGHT')));

    const addRes = JSON.parse((await post(port, '/api/action', { type: 'mcp.add', entry: { name: 'panel-added', command: 'node', args: ['x.js'] } }, cookie)).body);
    check('mcp.add 成功', () => assert.strictEqual(addRes.ok, true));
    const settingsText = fs.readFileSync(path.join(home, '.gemini', 'settings.json'), 'utf8');
    check('mcp.add 写入 settings.json', () => assert.ok(settingsText.includes('panel-added')));

    const delRes = JSON.parse((await post(port, '/api/action', { type: 'mcp.remove', name: 'panel-added' }, cookie)).body);
    check('mcp.remove 成功', () => assert.strictEqual(delRes.ok, true));
    check('mcp.remove 已生效', () => assert.ok(!fs.readFileSync(path.join(home, '.gemini', 'settings.json'), 'utf8').includes('panel-added')));

    const doctor = JSON.parse((await post(port, '/api/action', { type: 'doctor' }, cookie)).body);
    check('doctor 动作返回检查项', () => assert.ok(Array.isArray(doctor.result.checks) && doctor.result.checks.length >= 8));

    const bogus = await post(port, '/api/action', { type: 'nope' }, cookie);
    check('未知动作 → 400', () => assert.strictEqual(bogus.status, 400));
    const unauthAction = await post(port, '/api/action', { type: 'doctor' });
    check('动作无令牌 → 401', () => assert.strictEqual(unauthAction.status, 401));

    console.log('生命周期');
    const again = await P.ensureStarted({ port: 0 });
    check('ensureStarted 幂等', () => assert.strictEqual(again.port, port));
    P.stop();
    const after = await get(port, '/api/ping', cookie).then((r) => r.status, () => 'closed');
    check('stop 后连接关闭', () => assert.ok(after === 'closed' || after >= 400));
  });

  F.rmrf(home);
  F.rmrf(appDir);

  console.log('\n' + (fails.length ? 'FAILED ' + fails.length + ' / ' + (pass + fails.length) : 'ALL PASS ' + pass));
  if (fails.length) {
    for (const f of fails) console.log('  ! ' + f);
    process.exitCode = 1;
  }
}

main().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
