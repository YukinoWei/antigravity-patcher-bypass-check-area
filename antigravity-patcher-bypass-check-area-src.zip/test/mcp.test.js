'use strict';
/**
 * MCP 协议层测试：真的把 server.js 当子进程跑起来，用 stdin/stdout 走 JSON-RPC。
 * 运行：ELECTRON_RUN_AS_NODE=1 "…" test/mcp.test.js
 */
const assert = require('assert');
const path = require('path');
const { spawn } = require('child_process');
const F = require('./fixture');

const ROOT = path.join(__dirname, '..');
const SERVER = path.join(ROOT, 'server.js');

let pass = 0;
const fails = [];
function check(name, fn) {
  try {
    fn();
    pass++;
    console.log('  ✓ ' + name);
  } catch (err) {
    fails.push(name + ' → ' + err.message);
    console.log('  ✗ ' + name + ' → ' + err.message);
  }
}

function startServer(env) {
  const child = spawn(process.execPath, [SERVER], {
    cwd: ROOT,
    env: Object.assign({}, process.env, { ELECTRON_RUN_AS_NODE: '1', AG2_NO_AUTOFIX: '1' }, env || {}),
    stdio: ['pipe', 'pipe', 'pipe'],
    windowsHide: true,
  });
  let buf = '';
  const waiters = new Map();
  const stray = [];
  child.stdout.setEncoding('utf8');
  child.stdout.on('data', (chunk) => {
    buf += chunk;
    let idx;
    while ((idx = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, idx).trim();
      buf = buf.slice(idx + 1);
      if (!line) continue;
      let msg;
      try {
        msg = JSON.parse(line);
      } catch {
        continue;
      }
      if (msg.id != null && waiters.has(String(msg.id))) {
        const w = waiters.get(String(msg.id));
        waiters.delete(String(msg.id));
        w(msg);
      } else {
        stray.push(msg);
      }
    }
  });
  child.stderr.setEncoding('utf8');
  let stderr = '';
  child.stderr.on('data', (c) => {
    stderr += c;
  });

  let seq = 0;
  const send = (obj) => child.stdin.write(JSON.stringify(obj) + '\n');
  const request = (method, params) => {
    const id = ++seq;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('超时：' + method)), 8000);
      waiters.set(String(id), (m) => {
        clearTimeout(timer);
        resolve(m);
      });
      send({ jsonrpc: '2.0', id, method, params });
    });
  };
  const raw = (text) => child.stdin.write(text);
  return { child, request, send, raw, stray: () => stray, stderr: () => stderr, stop: () => child.kill() };
}

async function main() {
  const home = F.makeHome({});
  const appDir = F.makeApp({});
  const env = { AG2_HOME: home, AG2_APP_DIR: appDir, APPDATA: path.join(home, 'AppData', 'Roaming') };
  const s = startServer(env);

  try {
    console.log('MCP 协议');
    const init = await s.request('initialize', { protocolVersion: '2025-06-18', capabilities: {}, clientInfo: { name: 'test', version: '0' } });
    check('initialize 返回协议版本', () => assert.ok(['2024-11-05', '2025-03-26', '2025-06-18'].includes(init.result.protocolVersion)));
    check('serverInfo 名称正确', () => assert.strictEqual(init.result.serverInfo.name, 'antigravity2-plugin'));
    check('声明 tools 能力', () => assert.ok(init.result.capabilities.tools));
    s.send({ jsonrpc: '2.0', method: 'notifications/initialized' });

    const ping = await s.request('ping', {});
    check('ping 返回空结果', () => assert.deepStrictEqual(ping.result, {}));

    const list = await s.request('tools/list', {});
    const tools = list.result.tools;
    check('工具数量 21', () => assert.strictEqual(tools.length, 21));
    check('工具名唯一', () => assert.strictEqual(new Set(tools.map((t) => t.name)).size, tools.length));
    check('每个工具都有 inputSchema', () => assert.ok(tools.every((t) => t.inputSchema && t.inputSchema.type === 'object')));
    check('包含 ag2_status', () => assert.ok(tools.some((t) => t.name === 'ag2_status')));

    const status = await s.request('tools/call', { name: 'ag2_status', arguments: {} });
    const st = JSON.parse(status.result.content[0].text);
    check('ag2_status 读到夹具版本', () => assert.strictEqual(st.app.version, '2.28.2'));
    check('ag2_status 报告未解锁', () => assert.strictEqual(st.languageServer.unlock.state, 'unpatched'));
    check('ag2_status 读到调试端口', () => assert.strictEqual(st.runtime.appRunningPort, 9333));

    const mcpList = await s.request('tools/call', { name: 'ag2_mcp_list', arguments: {} });
    const ml = JSON.parse(mcpList.result.content[0].text);
    check('ag2_mcp_list 读到已有服务器', () => assert.ok(ml.servers.some((x) => x.name === 'existing' && x.transport === 'stdio')));
    check('ag2_mcp_list 路径正确', () => assert.strictEqual(ml.path, path.join(home, '.gemini', 'settings.json')));

    const skills = await s.request('tools/call', { name: 'ag2_skills_list', arguments: {} });
    check('ag2_skills_list 读到技能', () => assert.ok(JSON.parse(skills.result.content[0].text).skills.some((x) => x.name === 'demo-skill')));

    const logs = await s.request('tools/call', { name: 'ag2_logs_tail', arguments: { source: 'language_server', lines: 5 } });
    const lg = JSON.parse(logs.result.content[0].text);
    check('ag2_logs_tail 读到末尾行', () => assert.ok(lg.language_server.lines.includes('ls line 2')));

    const proj = await s.request('tools/call', { name: 'ag2_projects_list', arguments: {} });
    check('ag2_projects_list 读到项目', () => assert.ok(JSON.parse(proj.result.content[0].text).projects.some((x) => x.title === 'Demo Project')));

    const setRes = await s.request('tools/call', { name: 'ag2_settings_set', arguments: { key: 'themeMode', value: 'THEME_MODE_LIGHT' } });
    check('ag2_settings_set 成功', () => assert.strictEqual(JSON.parse(setRes.result.content[0].text).changed, true));
    const cfg = require('fs').readFileSync(path.join(home, '.gemini', 'config', 'config.json'), 'utf8');
    check('设置写入 config.json', () => assert.ok(cfg.includes('THEME_MODE_LIGHT')));
    check('写入前生成备份', () => assert.ok(require('fs').existsSync(path.join(home, '.gemini', 'config', 'config.json.bak'))));

    const mcpAdd = await s.request('tools/call', { name: 'ag2_mcp_add', arguments: { name: 'added-by-test', command: 'node', args: ['x.js'] } });
    check('ag2_mcp_add 成功', () => assert.strictEqual(JSON.parse(mcpAdd.result.content[0].text).name, 'added-by-test'));
    const settings = JSON.parse(require('fs').readFileSync(path.join(home, '.gemini', 'settings.json'), 'utf8'));
    check('settings.json 保留原有键', () => assert.strictEqual(settings.theme, 'dark'));
    check('settings.json 写入新服务器', () => assert.ok(settings.mcpServers['added-by-test']));

    const badTool = await s.request('tools/call', { name: 'nope', arguments: {} });
    check('未知工具返回 -32602', () => assert.strictEqual(badTool.error.code, -32602));

    const unknown = await s.request('resources/nonexistent', {});
    check('未知方法 -32601', () => assert.strictEqual(unknown.error.code, -32601));

    s.raw('{not json}\n');
    await new Promise((r) => setTimeout(r, 250));
    const parseErr = s.stray().find((m) => m.error && m.error.code === -32700);
    check('非法 JSON 返回 -32700', () => assert.ok(parseErr));

    const batch = await new Promise((resolve, reject) => {
      const id1 = 9001;
      const id2 = 9002;
      const timer = setTimeout(() => reject(new Error('批量超时')), 5000);
      const poll = setInterval(() => {
        const hit = s.stray().filter((m) => m.id === id1 || m.id === id2);
        if (hit.length === 2) {
          clearInterval(poll);
          clearTimeout(timer);
          resolve(hit);
        }
      }, 50);
      s.raw(JSON.stringify([{ jsonrpc: '2.0', id: id1, method: 'ping' }, { jsonrpc: '2.0', id: id2, method: 'ping' }]) + '\n');
    });
    check('批量请求逐个响应', () => assert.strictEqual(batch.length, 2));
  } finally {
    s.stop();
    await new Promise((r) => setTimeout(r, 120));
    F.rmrf(home);
    F.rmrf(appDir);
  }

  console.log('\n' + (fails.length ? 'FAILED ' + fails.length + ' / ' + (pass + fails.length) : 'ALL PASS ' + pass));
  if (fails.length) {
    for (const f of fails) console.log('  ! ' + f);
    process.exitCode = 1;
  }
}

main().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
