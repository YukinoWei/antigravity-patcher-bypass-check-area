'use strict';
/**
 * 真机验收：完全按 Antigravity 2.0 的方式拉起已注册的 MCP 服务器
 * （直接执行 settings.json 里 mcpServers["antigravity2-plugin"].command），
 * 握手、列工具、调 status，确认「注册项可用」。
 *
 *   node test/verify-registered.js
 */
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');

const NAME = 'antigravity2-plugin';

function settingsPath() {
  return path.join(process.env.AG2_HOME || os.homedir(), '.gemini', 'settings.json');
}

function main() {
  const sp = settingsPath();
  assert.ok(fs.existsSync(sp), '缺少 settings.json: ' + sp);
  const settings = JSON.parse(fs.readFileSync(sp, 'utf8'));
  const entry = (settings.mcpServers || {})[NAME];
  assert.ok(entry, '未注册 ' + NAME + '，先运行 ag2 install');
  assert.ok(entry.command, '注册项缺少 command');

  const isWin = process.platform === 'win32';
  const child = isWin
    ? spawn(process.env.ComSpec || 'cmd.exe', ['/c', entry.command, ...(entry.args || [])], { stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true })
    : spawn(entry.command, entry.args || [], { stdio: ['pipe', 'pipe', 'pipe'] });

  let buf = '';
  let stderr = '';
  const waiters = new Map();
  child.stdout.setEncoding('utf8');
  child.stderr.setEncoding('utf8');
  child.stderr.on('data', (c) => (stderr += c));
  child.stdout.on('data', (chunk) => {
    buf += chunk;
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).trim();
      buf = buf.slice(i + 1);
      if (!line) continue;
      let msg;
      try {
        msg = JSON.parse(line);
      } catch {
        continue;
      }
      const w = waiters.get(String(msg.id));
      if (w) {
        waiters.delete(String(msg.id));
        w(msg);
      }
    }
  });

  let seq = 0;
  const call = (method, params) =>
    new Promise((resolve, reject) => {
      const id = ++seq;
      const timer = setTimeout(() => reject(new Error('超时: ' + method + (stderr ? '\nstderr: ' + stderr.slice(0, 800) : ''))), 20000);
      waiters.set(String(id), (m) => {
        clearTimeout(timer);
        resolve(m);
      });
      child.stdin.write(JSON.stringify({ jsonrpc: '2.0', id, method, params }) + '\n');
    });

  const done = () => {
    try {
      child.stdin.end();
    } catch {}
    setTimeout(() => child.kill(), 200);
  };

  (async () => {
    console.log('注册项: ' + entry.command);
    const init = await call('initialize', { protocolVersion: '2025-06-18', capabilities: {}, clientInfo: { name: 'verify', version: '0' } });
    assert.strictEqual(init.result.serverInfo.name, NAME);
    console.log('  ✓ initialize 协议 ' + init.result.protocolVersion + ' / ' + init.result.serverInfo.name + ' v' + init.result.serverInfo.version);
    child.stdin.write(JSON.stringify({ jsonrpc: '2.0', method: 'notifications/initialized' }) + '\n');

    const list = await call('tools/list', {});
    assert.strictEqual(list.result.tools.length, 21);
    console.log('  ✓ tools/list 返回 21 个工具');

    const st = await call('tools/call', { name: 'ag2_status', arguments: {} });
    const data = JSON.parse(st.result.content[0].text);
    assert.ok(data.installed, '未检测到 2.0 安装');
    console.log('  ✓ ag2_status: ' + data.app.version + ' / 闸门 ' + data.languageServer.unlock.state + ' / 端口 ' + data.runtime.appRunningPort);

    const doc = await call('tools/call', { name: 'ag2_doctor', arguments: {} });
    const doctor = JSON.parse(doc.result.content[0].text);
    console.log('  ✓ ag2_doctor: ' + (doctor.ok ? '全部通过' : doctor.checks.filter((c) => !c.ok).map((c) => c.name).join(', ') + ' 异常') + '（' + doctor.checks.length + ' 项）');

    done();
    console.log('\n注册项可用：Antigravity 2.0 重启后即可加载。');
  })().catch((err) => {
    done();
    console.error('\n验收失败: ' + err.message);
    if (stderr) console.error('stderr: ' + stderr.slice(0, 1200));
    process.exitCode = 1;
  });
}

main();
