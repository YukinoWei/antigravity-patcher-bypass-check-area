'use strict';
/**
 * 安装器测试：在夹具 HOME + 夹具安装目录上跑完整 install / status / uninstall 流程。
 */
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const F = require('./fixture');

let pass = 0;
const fails = [];
function check(name, fn) {
  try {
    fn();
    pass++;
    console.log('  ✓ ' + name);
  } catch (err) {
    fails.push(name + ' → ' + err.message);
    console.log('  ✗ ' + name + ' → ' + err.message);
  }
}

async function main() {
  const home = F.makeHome({});
  const appDir = F.makeApp({ version: '2.28.2' });
  const env = { AG2_HOME: home, AG2_APP_DIR: appDir, APPDATA: path.join(home, 'AppData', 'Roaming'), AG2_NODE: process.execPath };

  await F.withEnv(env, async () => {
    const INSTALL = require('../install');
    const R = require('../lib/runtime');

    console.log('安装计划（dry-run）');
    const plan = INSTALL.install({ dryRun: true });
    check('dry-run 报告应用版本', () => assert.strictEqual(plan.version, '2.28.2'));
    check('dry-run 不落地文件', () => assert.ok(!fs.existsSync(path.join(home, '.gemini', 'ag2-plugin', 'app'))));
    check('dry-run 选择 node 运行时', () => assert.strictEqual(plan.runtime.kind, 'node'));

    console.log('安装');
    const res = INSTALL.install({ autostart: false });
    const pp = INSTALL.pluginPaths();
    check('安装返回成功', () => assert.ok(res.ok));
    check('server.js 已复制', () => assert.ok(fs.existsSync(path.join(pp.app, 'server.js'))));
    check('lib/mcp.js 已复制', () => assert.ok(fs.existsSync(path.join(pp.app, 'lib', 'mcp.js'))));
    check('panel/index.html 已复制', () => assert.ok(fs.existsSync(path.join(pp.app, 'panel', 'index.html'))));
    check('test/ 未被复制', () => assert.ok(!fs.existsSync(path.join(pp.app, 'test'))));
    check('垫片存在', () => assert.ok(fs.existsSync(R.isWin ? pp.shimWin : pp.shimPosix)));

    console.log('安装即自动应用');
    const lsFile = path.join(appDir, 'resources', 'bin', 'language_server.exe');
    check('安装返回 heal 结果', () => assert.ok(res.heal));
    check('安装即修好闸门', () => assert.strictEqual(res.heal.result, 'patched'));
    check('语言服务器已解锁', () => assert.strictEqual(R.analyzeBinary(lsFile).state, 'patched'));
    check('生成 .agybak 备份', () => assert.ok(fs.existsSync(lsFile + '.agybak')));
    check('heal.js 已复制', () => assert.ok(fs.existsSync(path.join(pp.app, 'heal.js'))));
    check('lib/heal.js 已复制', () => assert.ok(fs.existsSync(path.join(pp.app, 'lib', 'heal.js'))));
    check('lib/autostart.js 已复制', () => assert.ok(fs.existsSync(path.join(pp.app, 'lib', 'autostart.js'))));
    check('步骤里报告自动修复', () => assert.ok(res.steps.some((x) => x.indexOf('自动修复') === 0)));
    check('--no-autostart 时跳过定时任务', () => assert.strictEqual(res.autostart, null));

    const shim = fs.readFileSync(R.isWin ? pp.shimWin : pp.shimPosix, 'utf8');
    check('垫片指向 server.js', () => assert.ok(shim.includes(path.join(pp.app, 'server.js'))));
    check('垫片使用所选运行时', () => assert.ok(shim.includes(process.execPath)));

    const settings = JSON.parse(fs.readFileSync(pp.settings, 'utf8'));
    check('注册到 mcpServers', () => assert.ok(settings.mcpServers['antigravity2-plugin']));
    check('注册项为 stdio 命令', () => assert.strictEqual(settings.mcpServers['antigravity2-plugin'].command, R.isWin ? pp.shimWin : pp.shimPosix));
    check('保留原有 MCP 服务器', () => assert.ok(settings.mcpServers.existing));
    check('保留 settings.json 其它键', () => assert.strictEqual(settings.theme, 'dark'));
    check('settings.json 已备份', () => assert.ok(fs.existsSync(pp.settings + '.bak')));

    check('技能已安装', () => assert.ok(fs.existsSync(path.join(home, '.gemini', 'skills', 'ag2-desktop', 'SKILL.md'))));
    check('技能内容带 frontmatter', () => assert.ok(fs.readFileSync(path.join(home, '.gemini', 'skills', 'ag2-desktop', 'SKILL.md'), 'utf8').startsWith('---')));

    console.log('状态');
    const st = INSTALL.status();
    check('status 报告已安装', () => assert.strictEqual(st.installed, true));
    check('status 报告已注册', () => assert.strictEqual(st.registered, true));
    check('status 报告技能就绪', () => assert.strictEqual(st.skillExists, true));

    console.log('重复安装');
    const again = INSTALL.install({ autostart: false });
    check('重复安装成功', () => assert.ok(again.ok));
    check('重复安装不再写二进制', () => assert.strictEqual(again.heal.result, 'already'));
    const settings2 = JSON.parse(fs.readFileSync(pp.settings, 'utf8'));
    check('重复安装不重复注册', () => assert.strictEqual(Object.keys(settings2.mcpServers).filter((k) => k === 'antigravity2-plugin').length, 1));

    console.log('卸载');
    const un = INSTALL.uninstall({});
    check('卸载成功', () => assert.ok(un.ok));
    const settings3 = JSON.parse(fs.readFileSync(pp.settings, 'utf8'));
    check('卸载移除注册项', () => assert.ok(!settings3.mcpServers['antigravity2-plugin']));
    check('卸载保留其它服务器', () => assert.ok(settings3.mcpServers.existing));
    check('卸载删除插件目录', () => assert.ok(!fs.existsSync(pp.app)));
    check('卸载删除垫片', () => assert.ok(!fs.existsSync(R.isWin ? pp.shimWin : pp.shimPosix)));
    check('卸载删除技能', () => assert.ok(!fs.existsSync(path.join(home, '.gemini', 'skills', 'ag2-desktop'))));
    check('卸载后 status 为未安装', () => assert.strictEqual(INSTALL.status().installed, false));
  });

  F.rmrf(home);
  F.rmrf(appDir);

  console.log('\n' + (fails.length ? 'FAILED ' + fails.length + ' / ' + (pass + fails.length) : 'ALL PASS ' + pass));
  if (fails.length) {
    for (const f of fails) console.log('  ! ' + f);
    process.exitCode = 1;
  }
}

main().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
