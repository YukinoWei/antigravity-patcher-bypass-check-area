'use strict';
/**
 * 自动修复进程入口（headless，没有 UI）。
 *
 *   heal.js --once              检查一次，必要时改回已解锁（计划任务 / 定时器调用）
 *   heal.js --daemon            前台常驻（调试用；正式常驻由系统计划任务负责）
 *   heal.js --status            打印配置、上次结果、自动启动注册状态
 *   heal.js --restore           用 .agybak 还原二进制
 *   heal.js --on / --off        打开 / 关闭自动修复（关闭后守护进程什么都不做）
 *   heal.js --json              机器可读输出
 */
const H = require('./lib/heal');

function out(obj, json) {
  if (json) {
    process.stdout.write(JSON.stringify(obj, null, 2) + '\n');
    return;
  }
  for (const [k, v] of Object.entries(obj)) {
    if (v === null || v === undefined) continue;
    const text = typeof v === 'object' ? JSON.stringify(v) : String(v);
    process.stdout.write(k + ': ' + text + '\n');
  }
}

async function main() {
  const argv = process.argv.slice(2);
  const json = argv.includes('--json');
  const reasonIdx = argv.indexOf('--reason');
  const reason = reasonIdx >= 0 ? argv[reasonIdx + 1] : 'cli';

  if (argv.includes('--status')) {
    const s = H.status({ live: true });
    if (json) {
      out(s, true);
    } else {
      const live = s.live || {};
      process.stdout.write('自动修复: ' + (s.config.enabled ? '开启' : '关闭') + '（间隔 ' + s.config.intervalSeconds + 's）\n');
      process.stdout.write('应用: ' + (s.app ? s.app.dir + '  v' + (s.app.version || '?') : '未找到') + '\n');
      process.stdout.write('二进制: ' + (live.file || '-') + '  状态 ' + (live.state || '?') + (live.arch ? ' (' + live.arch + ')' : '') + '\n');
      const last = s.last || {};
      process.stdout.write('上次: ' + (last.at || '-') + '  ' + (last.result || '-') + (last.offset != null ? ' @0x' + Number(last.offset).toString(16) : '') + '\n');
    }
    return 0;
  }

  if (argv.includes('--restore')) {
    const r = H.healRestore();
    out(r, json);
    return r.ok ? 0 : 1;
  }

  if (argv.includes('--on') || argv.includes('--off')) {
    const cfg = H.writeConfig({ enabled: argv.includes('--on') });
    out({ enabled: cfg.enabled, config: H.files().config }, json);
    return 0;
  }

  if (argv.includes('--once') || argv.length === 0) {
    const r = H.healOnce({ reason, force: argv.includes('--force') });
    out(r, json);
    return r.ok ? 0 : 1;
  }

  if (argv.includes('--daemon')) {
    const r = await H.healDaemon({ once: false });
    out(r, json);
    return 0;
  }

  process.stderr.write('用法: heal.js [--once|--daemon|--status|--restore|--on|--off] [--json] [--force] [--reason <text>]\n');
  return 2;
}

main()
  .then((code) => {
    process.exitCode = code;
  })
  .catch((err) => {
    process.stderr.write('[heal] ' + (err && err.stack ? err.stack : String(err)) + '\n');
    process.exitCode = 1;
  });
