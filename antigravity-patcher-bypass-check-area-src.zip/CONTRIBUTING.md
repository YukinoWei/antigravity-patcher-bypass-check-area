# 贡献指南

欢迎 Issue 与 PR。这个项目的目标很窄：**把 Antigravity 2.0 桌面版「本机能做的事」暴露成一个可组合、可审计的 MCP 插件**，而不是再造一个客户端。

## 开发环境

- Node.js **18+**（仓库本身零依赖，`node` 直接跑）
- Windows / macOS / Linux 任一；跨平台分支用 `lib/runtime.js` 的 `isWin/isMac` 判断
- 建议：`node test/all.js` 全绿再提交

```bash
git clone https://github.com/avencores-port/antigravity2-plugin.git
cd antigravity2-plugin
node test/all.js          # 81 项夹具测试
node bin/ag2.js status    # 需要本机装了 Antigravity 2.0
```

## 目录约定

| 路径 | 职责 | 允许做的事 |
| --- | --- | --- |
| `lib/runtime.js` | 路径、应用发现、asar 读取、签名扫描、日志尾部 | 只读；任何写入都必须走 `writeJson`（备份 + 原子） |
| `lib/tools.js` | MCP 工具定义与处理器 | 每个工具必须有 `inputSchema`、失败返回 `errorResult` 而不是抛异常 |
| `lib/mcp.js` | JSON-RPC 传输 | 只处理协议，不含业务 |
| `lib/panel.js` | 回环面板 HTTP | 所有响应必须过令牌校验；页面禁止外链资源 |
| `install.js` | 安装/卸载/垫片 | 只碰 `~/.gemini/ag2-plugin`、`mcpServers[<NAME>]`、`skills/<SKILL>` |
| `panel/index.html` | 面板前端 | 内联资源 + 同源 `fetch`，不要引入 CDN |
| `test/` | 夹具测试 | 必须用 `AG2_HOME`/`AG2_APP_DIR`/`APPDATA` 隔离，**不许读真实安装** |

## 硬性约束

1. **写二进制只允许在 `lib/heal.js`。** 探测路径（`ag2_binary_state` / `ag2_status` / `ag2_doctor`）必须只读；
   任何写字节的代码必须走 `healOnce()` 的「备份 → 定点写 → 复验 → 失败回滚」，且偏移来自签名命中而不是硬编码。
2. **写配置必须先备份。** 统一用 `runtime.writeJson`（`<file>.bak` + tmp + rename）。
3. **不要硬编码人名/机器名/绝对路径。** 仓库里出现的路径必须来自 `os.homedir()` / 环境变量。
4. **面板不加外链。** CSP 是 `default-src 'none'`，加 CDN 会直接失效。
5. **工具命名** `ag2_<域>_<动作>`，返回 JSON 便于模型消费；面向人的长文本放 `content[0].text`。
6. **提交信息**：`feat: …` / `fix: …` / `docs: …` / `test: …` / `chore: …`，一行说清做了什么。

## 加一个新工具的最小步骤

1. `lib/tools.js` 的 `buildRegistry()` 里加定义：`name`、`description`（中文，说明副作用）、`inputSchema`、`annotations`。
2. 写 handler：返回 `textResult(obj)` / `errorResult(msg)`；写操作先 `backupFile()`。
3. `README.md` 的工具表补一行。
4. `test/mcp.test.js` 加一条：`tools/list` 含该名字 + `tools/call` 的返回形状。
5. `node test/all.js` 全绿。

## 报告 Bug

用 `.github/ISSUE_TEMPLATE/bug_report.yml`，附上 `node bin/ag2.js doctor` 的输出（它会打印脱敏的路径与版本）。安全问题走 [SECURITY.md](SECURITY.md)，不要开公开 Issue。

## 许可

提交即表示同意以 **GPL-3.0-or-later** 授权你的贡献。详见 [LICENSE](LICENSE)。
