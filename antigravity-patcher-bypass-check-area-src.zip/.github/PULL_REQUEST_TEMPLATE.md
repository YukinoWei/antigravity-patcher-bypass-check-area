## 这个 PR 做了什么

<!-- 一句话；再补必要的上下文 -->

## 类型

- [ ] 新工具 / 新能力
- [ ] 修 bug
- [ ] 文档
- [ ] 重构（无行为变化）
- [ ] 测试

## 影响面

- [ ] 改了 `lib/runtime.js`（路径 / 发现 / asar / 签名扫描）
- [ ] 改了 `lib/tools.js`（MCP 工具契约变化 → 需同步 README 工具表）
- [ ] 改了 `lib/panel.js` / `panel/index.html`（需确认 CSP 与令牌校验仍生效）
- [ ] 改了 `install.js`（需确认只碰 `~/.gemini/ag2-plugin`、`mcpServers[<NAME>]`、`skills/<SKILL>`）

## 验证

- [ ] `node test/all.js` 全绿（81 项）
- [ ] 新增/修改的逻辑有对应断言
- [ ] 手测路径：<!-- 例如 node bin/ag2.js status / 面板打开 / 2.0 里调用工具 -->

## 约束自查

- [ ] 没有写入 `language_server` 或 `app.asar` 的代码
- [ ] 写配置走 `writeJson`（备份 + 原子写）
- [ ] 没有硬编码用户名 / 机器名 / 绝对路径
- [ ] 页面资源全部内联，未引入 CDN
