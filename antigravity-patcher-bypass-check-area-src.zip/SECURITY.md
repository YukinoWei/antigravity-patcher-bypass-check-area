# 安全策略

## 报告漏洞

请**不要**用公开 Issue 报告安全问题。优先使用 GitHub 的
[Private vulnerability reporting](https://docs.github.com/code-security/security-advisories/guidance-on-reporting-and-writing-information-about-vulnerabilities)
（仓库 → Security → Report a vulnerability），或发邮件给维护者。

报告请包含：影响版本、复现步骤、受影响的文件/函数、可能的利用方式。48 小时内会收到确认，修复后会在此处致谢（除非要求匿名）。

## 设计上的安全边界

本插件的定位是「本机运维工具」，它的信任模型很克制：

| 面 | 边界 |
| --- | --- |
| MCP 传输 | stdin/stdout，由宿主进程（Antigravity 2.0）拉起，不监听网络端口 |
| 控制面板 | 仅绑定 `127.0.0.1`；随机令牌写 `~/.gemini/ag2-plugin/panel-token`（`0600`）；首页需 `?token=`，随后下发 `HttpOnly; SameSite=Strict` Cookie；API 全部校验 |
| 面板页面 | 无外链资源；`Content-Security-Policy: default-src 'none'`，仅放行内联样式/脚本与同源 `fetch` |
| 写操作 | 先 `<file>.bak` 备份，再 `tmp + rename` 原子写；只改自己负责的键（`mcpServers.<name>`、`userSettings.<key>`、`app_storage.json` 单键） |
| 二进制（探测） | `ag2_binary_state` / `ag2_status` / `ag2_doctor` 只读扫描 `language_server(.exe)` 的签名，不写入 |
| 二进制（自动修复） | 仅 `lib/heal.js` 会写入，且限定在闸门命中的固定偏移：写前复制 `<ls>.agybak`，写后立刻复验，失败用备份回滚；`app.asar` 永不修改；`ag2 heal --off` 可完全关闭写入 |
| 定时任务 | 安装时注册一条每 5 分钟运行 `heal.cmd|heal.sh --once` 的系统任务（schtasks / LaunchAgent / systemd --user / crontab），卸载时移除；只执行插件目录内的脚本 |
| 进程 | 只 `spawn` 已定位的 `Antigravity.exe`（`ag2_launch`），不下载、不执行外部二进制 |
| 卸载 | 只删除自己创建的文件与注册项 |

## 明确不做的事

- 不收集遥测，不发网络请求（除本地回环）；`ag2_launch` 打开深链由系统协议处理器决定。
- 不提供远程服务、不代理网络：面板与 MCP 都只在本机回环/stdio 上工作。
- 自动修复的写入目标是本机已安装的 `language_server`，字节与偏移固定、可回滚；它不下载、不注入、不联网，
  也不修改 `app.asar`。是否启用由用户决定（默认开启，`ag2 heal --off` 关闭）。
- 不读取与 2.0 无关的用户文件；`ag2_skill_read` / `ag2_storage_get` 等仅限 `~/.gemini` 与
  `%APPDATA%\Antigravity` 下的已知路径。

## 支持范围

只对 `main` 分支最新提交 + 最新 Release 提供修复。第三方改动（fork、二次打包、注入补丁）不在此范围。
