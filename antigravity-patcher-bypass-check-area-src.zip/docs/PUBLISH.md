# 发布到 GitHub

## 0. 一次性准备

1. 安装 `gh`，登录：`gh auth login`
2. 仓库里的作者/发布者字段（`package.json` 的 `author`/`repository`/`homepage`/`bugs`、
   `plugin.json` 的 `author`/`repository`/`homepage`、README 徽章、`SECURITY.md`、
   Issue 模板里的链接，共 **17 处**）统一写成 `avencores-port`。
   如果这就是你的 GitHub 用户名，跳过本节；否则按下文替换：

```bash
grep -rn "avencores-port" --include="*.json" --include="*.md" --include="*.yml" . | grep -v node_modules
```

批量替换（Linux/macOS；Windows 用 git bash 同样可用）：

```bash
grep -rl "avencores-port" --include="*.json" --include="*.md" --include="*.yml" . \
  | xargs sed -i 's/avencores-port/<OWNER>/g'
```

## 1. 初始化并首推

```bash
cd antigravity2-plugin
git init -b main
git add -A
git commit -m "feat: Antigravity 2.0 desktop plugin (MCP server + skill + local panel)"
gh repo create antigravity2-plugin --public --source=. --remote=origin --push
```

## 2. 仓库设置

```bash
gh repo edit --description "MCP plugin for the Antigravity 2.0 desktop app: 18 tools + token-guarded local panel" \
  --add-topic antigravity --add-topic mcp --add-topic model-context-protocol \
  --add-topic language-server --add-topic gemini --add-topic electron \
  --add-topic ai-agent --add-topic plugin --add-topic cli \
  --enable-issues --enable-discussions
```

- 默认分支 `main`，合并策略建议 squash。
- 分支保护：`main` 要求 `test / windows-latest / node 22` 与 `test / ubuntu-latest / node 22` 通过。
- Settings → Security → 开启 **Private vulnerability reporting**（`SECURITY.md` 依赖它）。
- Settings → Code security → 开启 Dependabot alerts（本仓库零依赖，仅作监控）。

## 3. 发版

```bash
python build-zip.py          # → dist/antigravity2-plugin-1.0.0.zip
gh release create v1.0.0 dist/antigravity2-plugin-1.0.0.zip \
  --title "v1.0.0" --notes-file CHANGELOG.md
```

版本号同时改三处：`package.json`、`plugin.json`、`CHANGELOG.md`（`install.js` 复制的是仓库快照，无需另改）。

## 4. 发布前自查

```bash
node test/all.js                      # 81 项全绿
node bin/ag2.js doctor                # 12 项全过
node -e "JSON.parse(require('fs').readFileSync('plugin.json','utf8'))"
git status --short                    # 应无 *.bak / panel-token / dist / node_modules
grep -rInE "Administrator|逆向破解|deepseekharness|panel-token|SBER" . --exclude-dir=.git --exclude-dir=dist
```

最后一条应只在文档里命中 `panel-token` 这个**文件名**，不出现任何真实令牌值。

## 5. 徽章

README 顶部已放 CI / license / node 三个徽章；如果你的默认分支不是 `main`，改 `badge.svg` 后面的 `branch=main`。

## 6. 关于许可

上游 Antigravity 2.0 是闭源商业软件，本仓库只包含**自己写的代码**（探测、IO、面板、文档），
不含任何 Google 的资源或反编译产物；逆向发现以文档形式记录（`docs/REVERSE-ENGINEERING.md`）。
仓库以 GPL-3.0-or-later 发布，与上游 `open-antigravity-patcher` 生态保持兼容。
