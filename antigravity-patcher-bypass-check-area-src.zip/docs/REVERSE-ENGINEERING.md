# 逆向记录：Antigravity 2.0 桌面版（2.28.2）

本文记录插件的**事实来源**：哪些结论来自静态分析、哪些经过运行验证、哪些仍是未知。目标不是复刻客户端，而是把它「已经公开在本机的能力」接出来。

## 1. 目标与工具

| 项 | 值 |
| --- | --- |
| 主程序 | `%LOCALAPPDATA%\Programs\antigravity\Antigravity.exe`（Electron 44.5.1） |
| 应用包 | `resources/app.asar`，`package.json`: `name=antigravity`、`version=2.28.2`、`main=dist/main.js` |
| 后端 | `resources/bin/language_server(.exe)`（2.28.2 约 174 MB，Go 编译） |
| 方法 | 自写 asar 读取器（零依赖）→ 全量解包 1085 文件；`latin1` 字符串 + 预编译正则分块扫描二进制；`ELECTRON_RUN_AS_NODE=1 Antigravity.exe` 当 node 运行探针 |

## 2. asar 容器格式（已实测）

```
offset 0x00  u32 = 4                 # 结构版本
offset 0x04  u32 = headerSize        # 287692
offset 0x08  u32 = jsonSize          # 287680（含 4 字节对齐填充）
offset 0x0C  u32 = jsonStrLen        # 287674（真实 JSON 长度）
offset 0x10  json bytes              # 必须按 jsonStrLen 截断再 JSON.parse
dataStart = 8 + headerSize
entry.offset 相对 dataStart；entry.size 为字节数
```

**坑**：用 `jsonSize` 解析会得到 `Unexpected non-whitespace character after JSON at position 287674`。
另外 Electron 的 `fs` 补丁会劫持任何含 `.asar` 的路径（`Invalid package …`），宿主是 Electron 时必须 `process.noAsar = true`。

## 3. 启动链路（main.js）

```
language_server --standalone --override_ide_name antigravity --subclient_type hub
  --override_ide_version <appVersion> --override_user_agent_name antigravity
  --https_server_port 0 --csrf_token <64hex> --app_data_dir antigravity
  --api_server_url https://generativelanguage.googleapis.com
  --cloud_code_endpoint https://daily-cloudcode-pa.googleapis.com
  --enable_sidecars [--host_bridge_url=<url> --host_bridge_token=<token>] [--headless]
```

- 端口由 LS 动态选择（`DYNAMIC_PORT=0`），写入 `userData/DevToolsActivePort`（首行端口、次行 browser ws 路径）。
- 窗口加载 `WINDOW_ORIGIN + ':' + lsPort + '/'`，`WINDOW_ORIGIN='https://127.0.0.1'`；`DEV_URL` 可覆盖（本插件只读取端口，不干预启动参数）。
- 额外 env：`AGY_BROWSER_ACTIVE_PORT_FILE`、`CHROME_DEVTOOLS_MCP_JS=<resources>/app.asar.unpacked/node_modules/chrome-devtools-mcp/build/src/bin/chrome-devtools-mcp.js`。

## 4. 本机数据面（paths.js）

| 常量 | 值 |
| --- | --- |
| `getAppDataDir()` | `~/.gemini/antigravity` |
| 用户设置 | `~/.gemini/config/config.json` → `userSettings` |
| MCP 注册 | `~/.gemini/settings.json` → `mcpServers` |
| 技能 | `~/.gemini/skills/<name>/SKILL.md` |
| 应用存储 | `userData/app_storage.json`（键值，如 `ide-install-wizard-shown`） |
| 调试端口 | `userData/DevToolsActivePort` |
| 日志 | `app.getPath('logs')/language_server.log`、`main.log` |

`userData` 在 Windows 上是 `%APPDATA%\Antigravity`（`app.getName().toLowerCase().replace(/\s+/g,'')`）。

## 5. 插件面（三种，全部来自真实模块）

1. **MCP 服务器**：`settings.json.mcpServers`，`{command,args,env?}`（stdio）或 `{httpUrl}`（HTTP/SSE）。本插件注册 stdio 项并由宿主拉起。
2. **技能**：`skills/<name>/SKILL.md`，Agent 按需加载；本插件带 `ag2-desktop`。
3. **sidecar 扩展**：`--enable_sidecars` + 渲染层 IPC `extensions:send-authorities`，把 `authority → http://localhost:<port>` 存入 `customScheme.js` 的 `extensionAuthorities`；`protocol.handle('plugin')` 用 `net.fetch` 反代 `plugin://<authority>/<path>`（scheme 权限：standard/secure/supportFetchAPI/corsEnabled/allowServiceWorkers/codeCache）。**本插件未使用**：需在 LS 进程内注册 authority，属进程内注入。

## 6. IPC 通道清单（ipcHandlers.js）

`dialog:open-workspace|open-workspaces`、`updater:apply|quit-and-install|get-state|check-for-updates`、`notification:send|open-system-preferences`、`storage:get-items|update-items`、`logs:electron`、`extensions:send-authorities`、`agent:update-active-count`、`window:set-title-bar-overlay|minimize|maximize|unmaximize|is-maximized|close|toggle-devtools|show-context-menu|close-context-menu|zoom-in|zoom-out|reset-zoom`、`shell:open-external`（限 `http/https/antigravity-ide://`）、`shell:reveal-in-file-picker`（含 WSL 路径转换）、`ide:is-installed`、`wsl:get-state|connect`、`webview:execute-js-isolated-world`、`script-jail:run|abort`。

> 本插件只复用其中的**配置面**（`storage`、`logs` 的落盘文件），不调用 IPC——因为插件是独立进程，没有渲染层上下文。`script-jail` 的隔离模型（Worker + `agy-script-jail:port` 握手 + RSS/并发限额）是后续做「沙盒执行」工具的参考。

## 7. 其它可验证能力

- `menu.js`：New Window（Ctrl+Shift+N）、Docs、macOS Check for Updates、Connect to WSL / Reopen Locally（`--wsl-distro=<name>` 重启，状态存 `userData/WSL_STATE_FILE`）。
- `main.js`：单实例锁、`antigravity://` 协议注册与深链处理、`session-created` 里注入 WebAuthn / BeyondCorp PAC。
- `hostBridgeServer.js`：回环 Connect RPC `exa.host_bridge_pb.HostBridgeService`（`GetUpdateStatus`/`ApplyUpdate`），Bearer token + Host 校验。
- 初始化脚本里注入的默认 `userSettings`：`permissionPreset: AGENT_PERMISSION_PRESET_TURBO`、`nonWorkspaceFileAccessPolicy: AGENT_SETTING_POLICY_ALLOW`、`autoExecutionPolicy: CASCADE_COMMANDS_AUTO_EXECUTION_EAGER` 等。

## 8. 授权闸门签名（只读检测）

`language_server` 里 `hasValidAuth` 的 x64 形态（本仓库只读取、不写入）：

| 角色 | 字节 |
| --- | --- |
| 未解锁 | `80 78 08 00 74 ?? 48 8b ?? 24 ?? 48 89 ?? 60` |
| 已解锁 | `c6 40 08 01 90 90 48 8b ?? 24 ?? 48 89 ?? 60` |
| arm64 未解锁 | `03 20 40 39 [03 23 43 63 83 a3 c3 e3] .. 36 (?:....){1,2} 03 10 06 a9` |
| arm64 已解锁 | `23 00 80 52 03 20 00 39 (?:....){1,2} 03 10 06 a9` |

`ag2_binary_state` 用分块正则判定 `patched / unpatched / unsupported`，返回命中偏移与架构；**没有任何写字节的代码路径**（PR 里出现即拒，见 CONTRIBUTING）。

## 9. 未知与边界

- `services/`、`proto/`（Connect/gRPC 定义）未逐条还原，只确认了 host bridge 的两个方法。
- 渲染层前端为打包资源，未做反混淆；本插件不依赖它。
- sidecar authority 的注册时序（何时发 `extensions:send-authorities`、LS 侧如何校验）未验证，故未实现。
- Linux/macOS 安装布局按 `paths.js` 与常规 Electron 约定推断，未在真机验证。
