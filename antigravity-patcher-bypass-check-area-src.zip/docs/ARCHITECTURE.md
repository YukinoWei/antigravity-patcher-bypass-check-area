# 架构

插件是**三件套**：一个 stdio MCP 服务器（给模型用）、一个回环控制面板（给人用）、一份技能说明（给 Agent 用），共用同一套只读探测与幂等写入逻辑。

```
                     ┌──────────────────────────────┐
                     │  Antigravity 2.0 (Electron)  │
                     │  main.js ──spawn──► language_server.exe
                     │     │ 渲染层 (https://127.0.0.1:port/)
                     └─────┼────────────────────────┘
                           │ 读 ~/.gemini/settings.json → mcpServers
                           ▼
        ┌──────────────────────────────────────────┐
        │ run-mcp.cmd / run-mcp.sh  (垫片)          │
        │   ELECTRON_RUN_AS_NODE=1  <electron> …    │
        └──────────────┬───────────────────────────┘
                       ▼
   ┌────────────────────────────────────────────────────┐
   │ server.js → lib/mcp.js   JSON-RPC over stdio        │
   │                    │                                │
   │                    ▼                                │
   │            lib/tools.js   18 × ag2_*                │
   │              │        │        │                    │
   │      lib/runtime.js   │   install.js (安装期)        │
   │   (路径/asar/签名/日志) │   ~/.gemini/ag2-plugin/app   │
   └──────────────┬─────────────────────────────────────┘
                  ▼
   ┌────────────────────────────────────────────────────┐
   │ lib/panel.js  HTTP 127.0.0.1:47913 (+token)         │
   │ panel/index.html  状态 / 改设置 / 注册 MCP / 日志     │
   └────────────────────────────────────────────────────┘
```

## 模块职责

| 文件 | 输入 | 输出 | 关键约束 |
| --- | --- | --- | --- |
| `server.js` | argv、stdin | stdout JSON-RPC | 只做装配；异常写 stderr 并 `exit 1` |
| `lib/mcp.js` | 行分隔 JSON-RPC | 响应 / 通知 | 支持 `2024-11-05/2025-03-26/2025-06-18`；未知 method → `-32601`；解析失败 → `-32700`；批量数组与 `notifications/*` 静默处理 |
| `lib/tools.js` | `{name, arguments}` | `toolResult` | 契约：`{tools, handlers}`；handler 永不抛异常，失败返回 `errorResult`（内容 `isError:true`）；未知工具 → `-32602` |
| `lib/runtime.js` | 环境变量 | 事实对象 | 纯探测 + 有备份的写入；`AG2_HOME`/`AG2_APP_DIR`/`AG2_NODE` 供测试与自定义安装 |
| `lib/heal.js` | `{reason, force}` | 结果对象 | 自动修复：`analyzeBinary` → 快速路径缓存 → 备份 `<ls>.agybak` → 定点写 → 复验 → 失败回滚；写失败按 `EBUSY/EPERM/EACCES/ETXTBSY/EBADF` 归类为 `locked`（可重试）；`heal.lock` 带 pid，20 分钟判陈旧 |
| `lib/autostart.js` | `{intervalSeconds}` | 注册结果 | 三平台定时触发：Windows 先试 `schtasks`，被拒（无管理员权限）则写 `Startup/ag2-heal.vbs`，用 wscript 静默常驻 `--daemon`；macOS LaunchAgent；Linux systemd --user（无 systemd 退回 crontab）；垫片 `heal.cmd|heal.sh` 只调用插件目录内的 `heal.js` |
| `lib/panel.js` | HTTP | JSON / HTML | 仅 `127.0.0.1`；令牌来自 `panel-token`（`0600`，24B hex）；`/` 需 `?token=` 换 Cookie；CSP `default-src 'none'` |
| `install.js` | 仓库目录 | `~/.gemini/ag2-plugin` + 注册项 | 只写自建路径；`settings.json` 只动 `mcpServers[name]`；写前 `.bak` |
| `bin/ag2.js` | 子命令 | 文本 | 与 MCP 工具同源调用，不重复实现逻辑 |

## 请求生命周期（工具调用）

1. `mcp.js` 读到一行 JSON → 校验 `jsonrpc`/`method`。
2. `tools/call` → `registry.handlers[name](args)`。
3. handler 调 `runtime.*` 探测事实（`findApp()` 带缓存；`analyzeBinary()` 分块扫 174 MB，latin1 + 预编译正则，避免一次性 `Buffer` 复制）。
4. 需要写时：`backupFile(file)` → `writeJson(file, next)`（`tmp` 同目录 + `rename`，Windows 上 `rename` 覆盖需要先 `unlink`）。
5. 返回 `{content:[{type:'text',text:JSON.stringify(...)}], isError?}`。

## 自动修复的触发面

| 触发 | 入口 | 说明 |
| --- | --- | --- |
| 安装 | `install.js` → `healOnce({reason:'install'})` | 装完立刻修一次，结果写进安装日志 |
| 宿主拉起 | `server.js` → `spawnHealOnce('server-start')` | detached 子进程，不阻塞握手、不写 stdout；`AG2_NO_AUTOFIX=1` 关闭 |
| 定时 | `lib/autostart.js` → `heal.cmd --once` | 每 `intervalSeconds`（默认 300）一次；Windows 无管理员权限时改由登录启动的常驻守护 `--daemon`；更新把闸门改回去后由它改回 |
| 手动 | `ag2 heal` / `ag2_heal_now` | 排障或用户要求立即修复 |

状态机：`disabled`（开关关闭）· `missing`（找不到安装）· `already`（已解锁，可能带 `cached:true`）·
`patched`（本次写入并复验通过）· `locked`（文件被占用，下轮重试）· `unsupported`（签名不认识，绝不写）·
`verify-failed`（写了但复验失败，已回滚）· `busy`（另一个进程持锁）。

## 面板协议

| 路由 | 方法 | 说明 |
| --- | --- | --- |
| `/` | GET | 需 `?token=`；校验后下发 Cookie 并返回 `panel/index.html` |
| `/api/state` | GET | 聚合 `{app,run,settings,mcp,skills,projects,logs,meta}` |
| `/api/ping` | GET | 存活探测（含版本） |
| `/api/action` | POST | `{action, payload}`；动作：`settings.set` `mcp.add` `mcp.remove` `launch` `logs.tail` `storage.set` `doctor` |

`buildState()` 里的 `mcp` 来自 `readSettings()` 的 `data.mcpServers`，`settings.path` 用于展示文件位置。

## 安装布局

```
~/.gemini/
├─ ag2-plugin/
│  ├─ app/                 # 仓库快照（server.js, lib/, panel/, bin/, skill/）
│  ├─ run-mcp.cmd|.sh      # 垫片（按探测到的运行时生成）
│  ├─ panel-token           # 0600 随机令牌
│  └─ install.log
├─ settings.json           # + mcpServers["antigravity2-plugin"]
├─ skills/ag2-desktop/SKILL.md
└─ ag2-plugin…（不动 antigravity/、config/ 等既有目录）
```

`install.js --uninstall` 反向执行：删注册项（保留其它 server）、删技能目录、删 `ag2-plugin/`。

## 失败模式

| 现象 | 原因 | 处理 |
| --- | --- | --- |
| 工具返回 `未找到 Antigravity 2.0` | 非默认安装位置 | `AG2_APP_DIR=<dir>` 或 `ag2 install --app <dir>` |
| 垫片启动即退出 | 运行时不可执行 | `AG2_NODE=<node 绝对路径>` 重装 |
| 面板 401 | 未带令牌 / Cookie 过期 | 用 `ag2 panel` 打印的新链接 |
| `签名不唯一` / `unsupported` | 版本结构变化 | 只读上报，不猜测（见 README 签名表） |
| 写配置失败 `EPERM` | 文件被占用 | 退出 2.0 后重试 |

## 扩展点

- **新工具**：`lib/tools.js` 加定义 + handler + README 表 + `test/mcp.test.js` 断言。
- **新面板动作**：`lib/panel.js` 的 `handleAction` + `panel/index.html` 按钮。
- **sidecar（`plugin://`）**：2.0 的渲染层支持 `--enable_sidecars` 与 `extensions:send-authorities`，把 `plugin://<authority>/…` 反代到本地端口。本插件暂未使用——它需要在 LS 进程内注册 authority，属于「进程内注入」范畴，留作独立设计。
