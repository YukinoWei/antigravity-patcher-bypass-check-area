'use strict';
/**
 * Antigravity 2.0 桌面版插件（MCP server）
 *
 * 本文件是插件入口：实现 MCP（Model Context Protocol）stdio 服务端，
 * 把 Antigravity 2.0 桌面应用的真实能力（配置、MCP 服务器管理、技能、
 * 项目、日志、存储、启动、二进制状态）暴露成 agent 可直接调用的工具。
 *
 * 无第三方依赖，可被 node 直接运行，也可由 Antigravity.exe 自带
 * Electron 运行时（ELECTRON_RUN_AS_NODE=1）驱动。
 */
const { startServer } = require('./lib/mcp');
const { buildRegistry } = require('./lib/tools');
const { spawnHealOnce } = require('./lib/heal');

const SERVER_INFO = { name: 'antigravity2-plugin', version: require('./plugin.json').version };

if (require.main === module) {
  // 自动应用：每次 MCP 服务器被拉起时，后台检查一次闸门；被更新还原就顺手改回来。
  // 不阻塞握手、不写 stdout（见 lib/heal.js）。用 AG2_NO_AUTOFIX=1 可关闭。
  if (process.env.AG2_NO_AUTOFIX !== '1') {
    try {
      spawnHealOnce('server-start');
    } catch {
      /* 自愈失败不影响 MCP 服务 */
    }
  }
  startServer({ serverInfo: SERVER_INFO, buildRegistry }).catch((err) => {
    process.stderr.write('[antigravity2-plugin] fatal: ' + (err && err.stack ? err.stack : String(err)) + '\n');
    process.exit(1);
  });
}

module.exports = { SERVER_INFO };
